SUMMARY
=======

SiMON is a dll application that extends iMON manager software in order 
to monitor SMART/CPU temperatures with your VFD/LCD 16x2 indicator.
It preserves the original functionality of native iMON.


INSTALL
=======

Run simon.exe, follow the instructions.

Hint: One may experience application initialization error during iMON restart, 
      if correct version of Microsoft.VC90.CRT is missing.
      Please follow next link to solve this:

http://www.microsoft.com/downloads/details.aspx?FamilyID=9b2da534-3e03-4391-8a4d-074b9f2bc1bf&DisplayLang=en

Vista,7 users: Check documentation on how to run application with administrator privileges:

http://technet.microsoft.com/en-us/library/cc709691.aspx#BKMK_S2


After imon restart you should see temperatures on your VFD with default period of 30 seconds.

Owners of VFDs and iMON remote should also get information displayed with "Not Defined Command".


SSL facility is being provided via OpenSSL library: http://www.openssl.org/related/binaries.html.


MORE INFORMATION
================

Release Date: Jul-18-2013

changes:

- Fixes for Windows 8
- Fixes for dialog behaviour under AERO
- PWM: Fan calibration mechanism for QST/IT87 added
- Workaround for fake temperatures exposed by SSDs
- Multithread fixes
- Installer fixed for x64
- PWM Fan control for IT87**
- CPU load method improved
- MCP68 GPU (NVidia 7050/630a) temperature readings
- Intel QST temperature and Fan speed readings
- AMD RevG built-in additional offsets (+21C)
- CPU load hang on's fixed
- Fan speed readings via EC, IT87** chips family (x86,x64)
- ATI GPU temperatures support
- NVidia GPU temperatures support
- CPU load improved
- AMD Phenom, family 0x10 support
- S.M.A.R.T. health monitoring
- some types of SCSI and USB drives support
- e-mail check,up to 10 accounts (POP3,IMAP,SSL)
- config settings GUI
- static mode display
- CPU and memory usage display
- support under iMON manager v6.x,v7.x
- VFD/LCD support
- AMD,Intel core temperatures support
- AMD Brisbane offsets to correct accuracy of core sensors
- built-in APM manager which allows stand-by mode for HDD drives along with SMART
- adjustable show delay period
- adjustable update prompt period 
- panel timer to turn on/off display on schedule
- overheat alarm, action
- Vista x64 driver workaround
- FanMate hardware feature
- cyrillic fonts VFD support (displayed in upper case only)


Has been tested with Microsoft Windows XP x86,x64, Vista x64,
iMON manager 6.01.0202, 7.20.0502, 7.40.0806�, 7.60.0521, 7.61.0522, 7.77.1022,
7.78.1125, 7.80.1224, 7.85.0222, 7.86.0414, 7.87.0524, 7.89.0622, 8.00.0408

Hardware confirmed:

-GMC Noblesse AV-S1 (VFD)
-Antec Fusion (LCD)
-Silverstone LASCALA LC16B-MR (VFD)
-SilverStone MFP51 (LCD)
-Thermaltake BACH (VFD)
-Thermaltake Media LAB (VFD)


DUMMY VALUES
============

For those who experience dummy values (+13) on their VFD/LCD,
along with valid data in SiMON.log - this is not an issue,but caused
with fact you don't have required licence for SiMON.
Here you can get one - http://www.imonplugin.com/node/14 .


GRATITUDES TO
=============

- Alcahest, for his patience, ideas, and perfect testing skills.

