// DisplayTestDlg.h : header file
//

#pragma once

#define WM_DSP_PLUGIN_NOTIFY	WM_APP + 1001

// CDisplayTestDlg dialog
class CDisplayTestDlg : public CDialog
{
// Construction
public:
	CDisplayTestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_DISPLAYTEST_DIALOG };
	CString m_strLine1;
	CString m_strLine2;
	CString m_strLine3;

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	UINT m_uEqTimer;
	UINT m_uEqTimer2;
	BOOL m_bVfdConnected;
	BOOL m_bLcdConnected;

	void Init();
	void Uninit();
	void DisplayPluginMessage(UINT uErrCode, BOOL bError);
	void UpdateControlUI();

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT nIDEvent);
	DECLARE_MESSAGE_MAP()

	afx_msg void OnBnClickedButtonInit();
	afx_msg void OnBnClickedButtonVfdSendText();
	afx_msg void OnBnClickedButtonVfdRandomEq();
	afx_msg void OnBnClickedButtonLcdSendText();
	afx_msg void OnBnClickedButtonLcdRandomEq();
	afx_msg void OnLcdOrangeIcon();
	afx_msg void OnLcdMediaTypeIcon();
	afx_msg void OnLcdSpeakerIcon();
	afx_msg void OnLcdVideoCodecIcon();
	afx_msg void OnLcdAudioCodecIcon();
	afx_msg void OnLcdAspectRatioIcon();
	afx_msg void OnLcdEtcIcon();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);

	afx_msg LRESULT OnDisplayPluginNotify(WPARAM, LPARAM);
};
