// DisplayTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DisplayTest.h"
#include "DisplayTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CDisplayTestDlg dialog

CDisplayTestDlg::CDisplayTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDisplayTestDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	
	m_strLine1 = _T("");
	m_strLine2 = _T("");
	m_strLine3 = _T("");

	m_uEqTimer = 0;
	m_uEqTimer2 = 0;
	m_bVfdConnected = FALSE;
	m_bLcdConnected = FALSE;
}

void CDisplayTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Text(pDX, IDC_EDIT1, m_strLine1);
	DDX_Text(pDX, IDC_EDIT2, m_strLine2);
	DDX_Text(pDX, IDC_EDIT3, m_strLine3);
}

BEGIN_MESSAGE_MAP(CDisplayTestDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_DESTROY()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedButtonInit)
	ON_BN_CLICKED(IDC_BUTTON2, OnBnClickedButtonVfdSendText)
	ON_BN_CLICKED(IDC_BUTTON3, OnBnClickedButtonVfdRandomEq)
	ON_BN_CLICKED(IDC_BUTTON4, OnBnClickedButtonLcdSendText)
	ON_BN_CLICKED(IDC_BUTTON5, OnBnClickedButtonLcdRandomEq)

	ON_BN_CLICKED(IDC_ORANGE1, OnLcdOrangeIcon)
	ON_BN_CLICKED(IDC_ORANGE2, OnLcdOrangeIcon)
	ON_BN_CLICKED(IDC_ORANGE3, OnLcdOrangeIcon)
	ON_BN_CLICKED(IDC_ORANGE4, OnLcdOrangeIcon)
	ON_BN_CLICKED(IDC_ORANGE5, OnLcdOrangeIcon)
	ON_BN_CLICKED(IDC_ORANGE6, OnLcdOrangeIcon)
	ON_BN_CLICKED(IDC_ORANGE7, OnLcdOrangeIcon)
	ON_BN_CLICKED(IDC_ORANGE8, OnLcdOrangeIcon)
	ON_BN_CLICKED(IDC_ORANGE0, OnLcdOrangeIcon)
	ON_BN_CLICKED(IDC_MUSIC, OnLcdMediaTypeIcon)
	ON_BN_CLICKED(IDC_MOVIE, OnLcdMediaTypeIcon)
	ON_BN_CLICKED(IDC_PHOTO, OnLcdMediaTypeIcon)
	ON_BN_CLICKED(IDC_CD, OnLcdMediaTypeIcon)
	ON_BN_CLICKED(IDC_TV, OnLcdMediaTypeIcon)
	ON_BN_CLICKED(IDC_WEBCASTING, OnLcdMediaTypeIcon)
	ON_BN_CLICKED(IDC_NEWS, OnLcdMediaTypeIcon)
	ON_BN_CLICKED(IDC_SPK_L, OnLcdSpeakerIcon)
	ON_BN_CLICKED(IDC_SPK_C, OnLcdSpeakerIcon)
	ON_BN_CLICKED(IDC_SPK_R, OnLcdSpeakerIcon)
	ON_BN_CLICKED(IDC_SPK_SL, OnLcdSpeakerIcon)
	ON_BN_CLICKED(IDC_SPK_LFE, OnLcdSpeakerIcon)
	ON_BN_CLICKED(IDC_SPK_SR, OnLcdSpeakerIcon)
	ON_BN_CLICKED(IDC_SPK_RL, OnLcdSpeakerIcon)
	ON_BN_CLICKED(IDC_SPK_SPDIF, OnLcdSpeakerIcon)
	ON_BN_CLICKED(IDC_SPK_RR, OnLcdSpeakerIcon)
	ON_BN_CLICKED(IDC_AV_MPG, OnLcdVideoCodecIcon)
	ON_BN_CLICKED(IDC_AV_DIVX, OnLcdVideoCodecIcon)
	ON_BN_CLICKED(IDC_AV_XVID, OnLcdVideoCodecIcon)
	ON_BN_CLICKED(IDC_AV_WMV, OnLcdVideoCodecIcon)
	ON_BN_CLICKED(IDC_AV_MPA, OnLcdVideoCodecIcon)
	ON_BN_CLICKED(IDC_AV_AC3, OnLcdVideoCodecIcon)
	ON_BN_CLICKED(IDC_AV_DTS, OnLcdVideoCodecIcon)
	ON_BN_CLICKED(IDC_AV_WMA, OnLcdVideoCodecIcon)
	ON_BN_CLICKED(IDC_A_MP3, OnLcdAudioCodecIcon)
	ON_BN_CLICKED(IDC_A_OGG, OnLcdAudioCodecIcon)
	ON_BN_CLICKED(IDC_A_WMA, OnLcdAudioCodecIcon)
	ON_BN_CLICKED(IDC_A_WAV, OnLcdAudioCodecIcon)
	ON_BN_CLICKED(IDC_AR_SRC, OnLcdAspectRatioIcon)
	ON_BN_CLICKED(IDC_AR_FIT, OnLcdAspectRatioIcon)
	ON_BN_CLICKED(IDC_AR_TV, OnLcdAspectRatioIcon)
	ON_BN_CLICKED(IDC_AR_HDTV, OnLcdAspectRatioIcon)
	ON_BN_CLICKED(IDC_AR_SCR1, OnLcdAspectRatioIcon)
	ON_BN_CLICKED(IDC_AR_SCR2, OnLcdAspectRatioIcon)
	ON_BN_CLICKED(IDC_REPEAT, OnLcdEtcIcon)
	ON_BN_CLICKED(IDC_SHUFFLE, OnLcdEtcIcon)
	ON_BN_CLICKED(IDC_ALARM, OnLcdEtcIcon)
	ON_BN_CLICKED(IDC_REC, OnLcdEtcIcon)
	ON_BN_CLICKED(IDC_VOL, OnLcdEtcIcon)
	ON_BN_CLICKED(IDC_TIME, OnLcdEtcIcon)
	ON_WM_HSCROLL()

	ON_MESSAGE(WM_DSP_PLUGIN_NOTIFY, OnDisplayPluginNotify)
END_MESSAGE_MAP()


// CDisplayTestDlg message handlers

BOOL CDisplayTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	m_strLine1 = _T("SoundGraph, Inc.");
	m_strLine2 = _T("iMON Display API");
	m_strLine3 = _T("SoundGraph, Inc. iMON Display API");

	UpdateControlUI();

	CSliderCtrl* pSliderCtrl = (CSliderCtrl*)GetDlgItem(IDC_SLIDER1);
	if(pSliderCtrl)
	{
		pSliderCtrl->SetRange(0, 100);
		pSliderCtrl->SetPos(0);
	}

	UpdateData(FALSE);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDisplayTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDisplayTestDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDisplayTestDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CDisplayTestDlg::OnDestroy() 
{
	CDialog::OnDestroy();

	IMON_Display_Uninit();
}

void CDisplayTestDlg::OnTimer(UINT nIDEvent) 
{
	if(nIDEvent == 101)
	{
		DSPEQDATA eqData;
		for(int i=0; i<16;i++)
		{
			eqData.BandData[i] = rand()%100;
		}
		IMON_Display_SetVfdEqData(&eqData);
	}
	else if(nIDEvent == 102)
	{
		DSPEQDATA eqDataL;
		DSPEQDATA eqDataR;
		for(int i=0; i<16;i++)
		{
			eqDataL.BandData[i] = rand()%100;
			eqDataR.BandData[i] = rand()%100;
		}
		IMON_Display_SetLcdEqData(&eqDataL, &eqDataR);
	}
	CDialog::OnTimer(nIDEvent);
}


void CDisplayTestDlg::OnBnClickedButtonInit()
{
	if(IMON_Display_IsInited() != DSP_S_INITED)		Init();
	else											Uninit();
}

void CDisplayTestDlg::OnBnClickedButtonVfdSendText()
{
	UpdateData(TRUE);
	IMON_Display_SetVfdText((LPCTSTR)m_strLine1, (LPCTSTR)m_strLine2);
}

void CDisplayTestDlg::OnBnClickedButtonVfdRandomEq()
{
	if(m_uEqTimer)
	{	
		KillTimer(101);		m_uEqTimer = 0;		
		GetDlgItem(IDC_BUTTON3)->SetWindowText(_T("Start Random EQ"));
	}
	else
	{
		m_uEqTimer = SetTimer(101, 40, NULL);
		GetDlgItem(IDC_BUTTON3)->SetWindowText(_T("Stop Random EQ"));
	}
}

void CDisplayTestDlg::OnBnClickedButtonLcdSendText()
{
	UpdateData(TRUE);
	IMON_Display_SetLcdText((LPCTSTR)m_strLine3);
}

void CDisplayTestDlg::OnBnClickedButtonLcdRandomEq()
{
	if(m_uEqTimer2)
	{	
		KillTimer(102);		m_uEqTimer2 = 0;		
		GetDlgItem(IDC_BUTTON5)->SetWindowText(_T("Start Random EQ"));
	}
	else
	{
		m_uEqTimer2 = SetTimer(102, 40, NULL);
		GetDlgItem(IDC_BUTTON5)->SetWindowText(_T("Stop Random EQ"));
	}
}

void CDisplayTestDlg::OnLcdOrangeIcon()
{
	BYTE data[2];
	memset(data, 0, sizeof(BYTE)*2);

	if(((CButton*)GetDlgItem(IDC_ORANGE1))->GetCheck())		data[0] |= 0x80;
	if(((CButton*)GetDlgItem(IDC_ORANGE2))->GetCheck())		data[0] |= 0x40;
	if(((CButton*)GetDlgItem(IDC_ORANGE3))->GetCheck())		data[0] |= 0x20;
	if(((CButton*)GetDlgItem(IDC_ORANGE4))->GetCheck())		data[0] |= 0x10;
	if(((CButton*)GetDlgItem(IDC_ORANGE5))->GetCheck())		data[0] |= 0x08;
	if(((CButton*)GetDlgItem(IDC_ORANGE6))->GetCheck())		data[0] |= 0x04;
	if(((CButton*)GetDlgItem(IDC_ORANGE7))->GetCheck())		data[0] |= 0x02;
	if(((CButton*)GetDlgItem(IDC_ORANGE8))->GetCheck())		data[0] |= 0x01;
	if(((CButton*)GetDlgItem(IDC_ORANGE0))->GetCheck())		data[1] |= 0x80;

	IMON_Display_SetLcdOrangeIcon(data[0], data[1]);
}

void CDisplayTestDlg::OnLcdMediaTypeIcon()
{
	BYTE data = 0;

	if(((CButton*)GetDlgItem(IDC_MUSIC))->GetCheck())		data |= 0x80;
	if(((CButton*)GetDlgItem(IDC_MOVIE))->GetCheck())		data |= 0x40;
	if(((CButton*)GetDlgItem(IDC_PHOTO))->GetCheck())		data |= 0x20;
	if(((CButton*)GetDlgItem(IDC_CD))->GetCheck())			data |= 0x10;
	if(((CButton*)GetDlgItem(IDC_TV))->GetCheck())			data |= 0x08;
	if(((CButton*)GetDlgItem(IDC_WEBCASTING))->GetCheck())	data |= 0x04;
	if(((CButton*)GetDlgItem(IDC_NEWS))->GetCheck())		data |= 0x02;

	IMON_Display_SetLcdMediaTypeIcon(data);
}

void CDisplayTestDlg::OnLcdSpeakerIcon()
{
	BYTE data[2];
	memset(data, 0, sizeof(BYTE)*2);

	if(((CButton*)GetDlgItem(IDC_SPK_L))->GetCheck())		data[0] |= 0x80;
	if(((CButton*)GetDlgItem(IDC_SPK_C))->GetCheck())		data[0] |= 0x40;
	if(((CButton*)GetDlgItem(IDC_SPK_R))->GetCheck())		data[0] |= 0x20;
	if(((CButton*)GetDlgItem(IDC_SPK_SL))->GetCheck())		data[0] |= 0x10;
	if(((CButton*)GetDlgItem(IDC_SPK_LFE))->GetCheck())		data[0] |= 0x08;
	if(((CButton*)GetDlgItem(IDC_SPK_SR))->GetCheck())		data[0] |= 0x04;
	if(((CButton*)GetDlgItem(IDC_SPK_RL))->GetCheck())		data[0] |= 0x02;
	if(((CButton*)GetDlgItem(IDC_SPK_SPDIF))->GetCheck())	data[0] |= 0x01;
	if(((CButton*)GetDlgItem(IDC_SPK_RR))->GetCheck())		data[1] |= 0x80;

	IMON_Display_SetLcdSpeakerIcon(data[0], data[1]);
}

void CDisplayTestDlg::OnLcdVideoCodecIcon()
{
	BYTE data = 0;

	if(((CButton*)GetDlgItem(IDC_AV_MPG))->GetCheck())		data |= 0x80;
	if(((CButton*)GetDlgItem(IDC_AV_DIVX))->GetCheck())		data |= 0x40;
	if(((CButton*)GetDlgItem(IDC_AV_XVID))->GetCheck())		data |= 0x20;
	if(((CButton*)GetDlgItem(IDC_AV_WMV))->GetCheck())		data |= 0x10;
	if(((CButton*)GetDlgItem(IDC_AV_MPA))->GetCheck())		data |= 0x08;
	if(((CButton*)GetDlgItem(IDC_AV_AC3))->GetCheck())		data |= 0x04;
	if(((CButton*)GetDlgItem(IDC_AV_DTS))->GetCheck())		data |= 0x02;
	if(((CButton*)GetDlgItem(IDC_AV_WMA))->GetCheck())		data |= 0x01;

	IMON_Display_SetLcdVideoCodecIcon(data);
}

void CDisplayTestDlg::OnLcdAudioCodecIcon()
{
	BYTE data = 0;

	if(((CButton*)GetDlgItem(IDC_A_MP3))->GetCheck())		data |= 0x80;
	if(((CButton*)GetDlgItem(IDC_A_OGG))->GetCheck())		data |= 0x40;
	if(((CButton*)GetDlgItem(IDC_A_WMA))->GetCheck())		data |= 0x20;
	if(((CButton*)GetDlgItem(IDC_A_WAV))->GetCheck())		data |= 0x10;

	IMON_Display_SetLcdAudioCodecIcon(data);
}

void CDisplayTestDlg::OnLcdAspectRatioIcon()
{
	BYTE data = 0;

	if(((CButton*)GetDlgItem(IDC_AR_SRC))->GetCheck())		data |= 0x80;
	if(((CButton*)GetDlgItem(IDC_AR_FIT))->GetCheck())		data |= 0x40;
	if(((CButton*)GetDlgItem(IDC_AR_TV))->GetCheck())		data |= 0x20;
	if(((CButton*)GetDlgItem(IDC_AR_HDTV))->GetCheck())		data |= 0x10;
	if(((CButton*)GetDlgItem(IDC_AR_SCR1))->GetCheck())		data |= 0x08;
	if(((CButton*)GetDlgItem(IDC_AR_SCR2))->GetCheck())		data |= 0x04;

	IMON_Display_SetLcdAspectRatioIcon(data);
}

void CDisplayTestDlg::OnLcdEtcIcon()
{
	BYTE data = 0;

	if(((CButton*)GetDlgItem(IDC_REPEAT))->GetCheck())		data |= 0x80;
	if(((CButton*)GetDlgItem(IDC_SHUFFLE))->GetCheck())		data |= 0x40;
	if(((CButton*)GetDlgItem(IDC_ALARM))->GetCheck())		data |= 0x20;
	if(((CButton*)GetDlgItem(IDC_REC))->GetCheck())			data |= 0x10;
	if(((CButton*)GetDlgItem(IDC_VOL))->GetCheck())			data |= 0x08;
	if(((CButton*)GetDlgItem(IDC_TIME))->GetCheck())		data |= 0x04;

	IMON_Display_SetLcdEtcIcon(data);
}

void CDisplayTestDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	CSliderCtrl* pSliderCtrl = (CSliderCtrl*)GetDlgItem(IDC_SLIDER1);
	if( pSliderCtrl && pSliderCtrl->GetSafeHwnd() && 
		pScrollBar && pScrollBar->GetSafeHwnd() == pSliderCtrl->GetSafeHwnd() )
	{
		IMON_Display_SetLcdProgress(pSliderCtrl->GetPos(), 100);
	}
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

LRESULT CDisplayTestDlg::OnDisplayPluginNotify(WPARAM wParam, LPARAM lParam)
{
	if(!GetSafeHwnd() || !IsWindow(GetSafeHwnd()))		return 0;

	switch(wParam)
	{
	case DSPNM_PLUGIN_SUCCEED:
	case DSPNM_IMON_RESTARTED:
	case DSPNM_HW_CONNECTED:
		{
			GetDlgItem(IDC_BUTTON1)->EnableWindow(TRUE);
			m_bVfdConnected = FALSE;
			m_bLcdConnected = FALSE;
			if((lParam & DSPN_DSP_VFD) == DSPN_DSP_VFD)		m_bVfdConnected = TRUE;
			if((lParam & DSPN_DSP_LCD) == DSPN_DSP_LCD)		m_bLcdConnected = TRUE;
			UpdateControlUI();

			DisplayPluginMessage(wParam, FALSE);
		}
		break;

	case DSPNM_PLUGIN_FAILED:
	case DSPNM_HW_DISCONNECTED:
	case DSPNM_IMON_CLOSED:
		{
			GetDlgItem(IDC_BUTTON1)->EnableWindow(TRUE);
			m_bVfdConnected = FALSE;
			m_bLcdConnected = FALSE;
			UpdateControlUI();

			DisplayPluginMessage(lParam, TRUE);
		}
		break;

	case DSPNM_LCD_TEXT_SCROLL_DONE:
		{
			TRACE(_T("LCD Text Scroll Finished.\n"));
		}
		break;
	}
	return 0;
}

void CDisplayTestDlg::Init()
{
	Uninit();

	IMON_Display_Init(this->GetSafeHwnd(), WM_DSP_PLUGIN_NOTIFY);
	GetDlgItem(IDC_BUTTON1)->EnableWindow(FALSE);
}

void CDisplayTestDlg::Uninit()
{
	IMON_Display_Uninit();

	m_bVfdConnected = FALSE;
	m_bLcdConnected = FALSE;

	for(int i=IDC_ORANGE1;i<=IDC_AR_SCR2;i++)
	{
		if(GetDlgItem(i))
			((CButton*)GetDlgItem(i))->SetCheck(FALSE);
	}
	CSliderCtrl* pSliderCtrl = (CSliderCtrl*)GetDlgItem(IDC_SLIDER1);
	if(pSliderCtrl)	pSliderCtrl->SetPos(0);

	UpdateControlUI();
}

void CDisplayTestDlg::DisplayPluginMessage(UINT uErrCode, BOOL bError)
{
	CString strErrMsg = _T("");

	if(bError)
	{
		switch(uErrCode)
		{
		case DSPN_ERR_IN_USED:			strErrMsg = _T("Display Plug-in is Already Used by Other Application.");		break;
		case DSPN_ERR_HW_DISCONNECTED:	strErrMsg = _T("iMON HW is Not Connected.");									break;
		case DSPN_ERR_NOT_SUPPORTED_HW:	strErrMsg = _T("The Connected iMON HW doesn't Support Display Plug-in.");		break;
		case DSPN_ERR_PLUGIN_DISABLED:	strErrMsg = _T("Display Plug-in Mode Option is Disabled.");						break;
		case DSPN_ERR_IMON_NO_REPLY:	strErrMsg = _T("The Latest iMON is Not Installed or iMON Not Running.");		break;
		case DSPN_ERR_UNKNOWN:			strErrMsg = _T("Unknown Failure.");												break;
		}
	}
	else
	{
		switch(uErrCode)
		{
		case DSPNM_PLUGIN_SUCCEED:		strErrMsg = _T("Plug-in Mode Inited Successfully.");		break;
		case DSPNM_IMON_RESTARTED:		strErrMsg = _T("iMON Started and Plug-in Mode Inited.");		break;
		case DSPNM_HW_CONNECTED:		strErrMsg = _T("iMON HW Connected and Plug-in Mode Inited.");	break;
		}
	}
	GetDlgItem(IDC_STATIC_INFO)->SetWindowText((LPCTSTR)strErrMsg);
}

void CDisplayTestDlg::UpdateControlUI()
{
	GetDlgItem(IDC_STATIC_INFO)->SetWindowText(_T(""));
	
	if(IMON_Display_IsInited() != DSP_S_INITED)		GetDlgItem(IDC_BUTTON1)->SetWindowText(_T("Init Plug-in"));
	else											GetDlgItem(IDC_BUTTON1)->SetWindowText(_T("Uninit Plug-in"));

	for(int i=IDC_EDIT1;i<=IDC_BUTTON3;i++)
	{
		if(GetDlgItem(i))
			GetDlgItem(i)->EnableWindow(m_bVfdConnected);
	}
	for(int i=IDC_EDIT3;i<=IDC_SLIDER1;i++)
	{
		if(GetDlgItem(i))
			GetDlgItem(i)->EnableWindow(m_bLcdConnected);
	}
}
