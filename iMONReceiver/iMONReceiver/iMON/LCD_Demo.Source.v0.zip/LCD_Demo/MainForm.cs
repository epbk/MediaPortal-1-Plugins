﻿/*
 * Created by SharpDevelop.

Copyright (C) 2007 raypan
 
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

 */

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;
using iMonOEMLCD;
 

namespace LCD_Demo
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		LCD.Icons icon = new LCD.Icons();
		Int64 IconWord;
		
		[STAThread]
		public static void Main(string[] args)
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new MainForm());
		}
		
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			bool ret;
			Int32  vfdType=0x18; // iMon version 5 initialised with 0x16
								 // iMon version 6 uses 0x18 - no idea why the difference
			Int32  reserved=0x00008888;  // both versions send this long int 
			
			if (!iMONVFD_IsInited()) ret=iMONVFD_Init(vfdType,reserved);
			Console.WriteLine("Clear Display");
			LCD.ClearDisplay();
			LCD.ClearPixels();
			LCD.SendText(txtFirstLine.Text,txtSecondLine.Text);
			
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void BtnSendClick(object sender, EventArgs e)
		{
			byte [] EQData = new byte[17];
			Random random  = new Random();
			for (int k=0; k< 50; k++) {
				if (radioButton1.Checked==true) EQData[0]=0;  // from bottom
				if (radioButton2.Checked==true) EQData[0]=1;  // from top
				if (radioButton3.Checked==true) EQData[0]=2;  // from middle??
				if (radioButton4.Checked==true) EQData[0]=7;  // from top and bottom???
				// are there other options??
				
				if ((radioButton1.Checked == true) ||
				    (radioButton2.Checked == true)){
					for (int i=1; i<=16;i++) {
						EQData[i]= Convert.ToByte(Convert.ToChar(Convert.ToInt32(16 * random.NextDouble())));
					}
				}
				else {
				for (int i=1; i<=16;i++) {
				
					EQData[i]= Convert.ToByte(Convert.ToChar(Convert.ToInt32(8.0 * random.NextDouble()))  // lower nibble
					           +	Convert.ToChar(Convert.ToInt32(8.0 * random.NextDouble())<<4));   // upper nibble
				}
				}
				LCD.SetEQ(EQData);
				Thread.Sleep(100);
			}
		}
		
		
		void BtnScrollLinesClick(object sender, EventArgs e)
		{
			for (int i=0; i<=32; i++) {
			LCD.SetLineLength(i,0,0,0);
			Thread.Sleep(50);
			}
			for (int i=0; i<=32; i++) {
			LCD.SetLineLength(0,i,0,0);
			Thread.Sleep(50);
			}
			for (int i=0; i<=32; i++) {
			LCD.SetLineLength(0,0,i,0);
			Thread.Sleep(50);
			}
			for (int i=0; i<=32; i++) {
			LCD.SetLineLength(0,0,0,i);
			Thread.Sleep(50);
			}
		
			for (int i=0; i<=32; i++) {
			LCD.SetLineLength(-i,0,0,0);
			Thread.Sleep(20);
			}
			for (int i=0; i<=32; i++) {
			LCD.SetLineLength(0,-i,0,0);
			Thread.Sleep(20);
			}
			for (int i=0; i<=32; i++) {
			LCD.SetLineLength(0,0,-i,0);
			Thread.Sleep(20);
			}
			for (int i=0; i<=32; i++) {
			LCD.SetLineLength(0,0,0,-i);
			Thread.Sleep(20);
			}
			LCD.SendData(0x10ffffff00000000);
			LCD.SendData(0x110000ffffffffff);
		
		}
		
		void TxtFirstLineTextChanged(object sender, EventArgs e)
		{
			if(txtFirstLine.Text.Length <=16)
				LCD.SendText(txtFirstLine.Text,txtSecondLine.Text);
			
		}
		void TxtSecondLineTextChanged(object sender, EventArgs e)
		{
			if(txtSecondLine.Text.Length <=16)
				LCD.SendText(txtFirstLine.Text,txtSecondLine.Text);
			
		}
		
		void LblMusicMouseClick(object sender, MouseEventArgs e)
		{
			if (lblMusic.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.Music(true);
				lblMusic.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.Music(false);
				lblMusic.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);
		}
		
		
		void LblMovieMouseClick(object sender, MouseEventArgs e)
		{
			if (lblMovie.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.Movie(true);
				lblMovie.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.Movie(false);
				lblMovie.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);
		}
		
		void LblPhotoClick(object sender, EventArgs e)
		{
			
		}
		
		void LblPhotoMouseClick(object sender, MouseEventArgs e)
		{
			if (lblPhoto.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.Photo(true);
				lblPhoto.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.Photo(false);
				lblPhoto.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);
		}
		
		void LblMsicMouseClick(object sender, MouseEventArgs e)
		{
			
		}
		
		void LblCD_DVDMouseClick(object sender, MouseEventArgs e)
		{
			if (lblCD_DVD.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.CD_DVD(true);
				lblCD_DVD.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.CD_DVD(false);
				lblCD_DVD.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);			
		}
		
		void LblTVMouseClick(object sender, MouseEventArgs e)
		{
			if (lblTV.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.TV(true);
				lblCD_DVD.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.TV(false);
				lblTV.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);					
		}
		
		void LblWebMouseClick(object sender, MouseEventArgs e)
		{
			if (lblWeb.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.WebCast(true);
				lblWeb.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.WebCast(false);
				lblWeb.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);				
		}
		
		void LblNewsMouseClick(object sender, MouseEventArgs e)
		{
			if (lblNews.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.News(true);
				lblNews.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.News(false);
				lblNews.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);				
		}
		
		void BtnExitClick(object sender, EventArgs e)
		{
			LCD.ClearPixels();
			LCD.SendData(0x0100000000000000);
			LCD.SetLineLength(0,0,0,0);
			LCD.iMONVFD_Uninit();
			this.Close();
		}
		
		void LblMPGClick(object sender, EventArgs e)
		{
			if (lblMPG.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.MPG(true);
				lblMPG.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.MPG(false);
				lblMPG.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);			
		}
		
		void LblDivXClick(object sender, EventArgs e)
		{
			if (lblDivX.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.DivX(true);
				lblDivX.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.DivX(false);
				lblDivX.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);			
			
		}
		
		void LblXVidClick(object sender, EventArgs e)
		{
			if (lblXVid.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.xVid(true);
				lblXVid.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.xVid(false);
				lblXVid.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);			
			
		}
		
		void LblWMVClick(object sender, EventArgs e)
		{
			if (lblWMV.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.WMV(true);
				lblWMV.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.WMV(false);
				lblWMV.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);			
						
		}
		
		void LblMPG_2Click(object sender, EventArgs e)
		{
			if (lblMPG_2.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.MPG_2(true);
				lblMPG_2.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.MPG_2(false);
				lblMPG_2.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);			
		}
		
		void LblAC3Click(object sender, EventArgs e)
		{
			if (lblAC3.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.AC3(true);
				lblAC3.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.AC3(false);
				lblAC3.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);			
			
		}
		
		void LblDTSClick(object sender, EventArgs e)
		{
			if (lblDTS.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.DTS(true);
				lblDTS.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.DTS(false);
				lblDTS.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);			
			
		}
		
		void LblWMAClick(object sender, EventArgs e)
		{
			if (lblWMA.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.WMA(true);
				lblWMA.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.WMA(false);
				lblWMA.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);			
			
		}
		
		void LblMP3Click(object sender, EventArgs e)
		{
		
			if (lblMP3.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.MP3(true);
				lblMP3.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.MP3(false);
				lblMP3.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);			
			
		}
		
		void LblOGGClick(object sender, EventArgs e)
		{
			if (lblOGG.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.OGG(true);
				lblOGG.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.OGG(false);
				lblOGG.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);				
		}
		
		void LblWMA_2Click(object sender, EventArgs e)
		{
			if (lblWMA_2.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.WMA_2(true);
				lblWMA_2.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.WMA_2(false);
				lblWMA_2.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);				
		}
		
		void LblWAVClick(object sender, EventArgs e)
		{
			if (lblWAV.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.WAV(true);
				lblWAV.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.WAV(false);
				lblWAV.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);				
					
		}
		
		void LblTVClick(object sender, EventArgs e)
		{
			if (lblTV.BackColor == System.Drawing.Color.Gray){
				IconWord = icon.TV(true);
				lblTV.BackColor=System.Drawing.Color.AntiqueWhite;
			}
			else{
				IconWord = icon.TV(false);
				lblTV.BackColor=System.Drawing.Color.Gray;
			}
			LCD.SendData(IconWord);				
			
		}

        private void lblSRC_Click(object sender, EventArgs e)
        {
            if (lblSRC.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.SRC(true);
                lblSRC.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.SRC(false);
                lblSRC.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);	
        }

        private void lblFIT_Click(object sender, EventArgs e)
        {
            if (lblFIT.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.FIT(true);
                lblFIT.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.FIT(false);
                lblFIT.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);	
        }

        private void lblTV_2_Click(object sender, EventArgs e)
        {
        if (lblTV_2.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.TV_2(true);
                lblTV_2.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.TV_2(false);
                lblTV_2.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);	
        }

        private void lblHDTV_Click(object sender, EventArgs e)
        {
            if (lblHDTV.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.HDTV(true);
                lblHDTV.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.HDTV(false);
                lblHDTV.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);	
        }

        private void lblSCCR1_Click(object sender, EventArgs e)
        {
            if (lblSCR1.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.SCR1(true);
                lblSCR1.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.SCR1(true);
                lblSCR1.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);	
        }

        private void lblSCR2_Click(object sender, EventArgs e)
        {
            if (lblSCR2.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.SCR2(true);
                lblSCR2.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.SCR2(false);
                lblSCR2.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);	
        }


        private void lblL_Click(object sender, EventArgs e)
        {
            if (lblL.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.Left(true);
                lblL.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.Left(false);
                lblL.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);	
        }

        private void lblC_Click(object sender, EventArgs e)
        {
            if (lblC.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.Centre(true);
                lblC.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.Centre(false);
                lblC.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);	
        }

        private void lblR_Click(object sender, EventArgs e)
        {
            if (lblR.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.Right(true);
                lblR.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.Right(false);
                lblR.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);
        }

        private void lblSL_Click(object sender, EventArgs e)
        {
            if (lblSL.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.SL(true);
                lblSL.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.SL(false);
                lblSL.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);
        }

        private void lblSR_Click(object sender, EventArgs e)
        {
            if (lblSR.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.SR(true);
                lblSR.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.SR(false);
                lblSR.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);
        }

        private void lblLFE_Click(object sender, EventArgs e)
        {
            if (lblLFE.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.LFE(true);
                lblLFE.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.LFE(false);
                lblLFE.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);
        }

        private void lblSPDIF_Click(object sender, EventArgs e)
        {
            if (lblSPDIF.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.SPDIF(true);
                lblSPDIF.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.SPDIF(false);
                lblSPDIF.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);
        }

        private void lblRL_Click(object sender, EventArgs e)
        {
            if (lblRL.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.RL(true);
                lblRL.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.RL(false);
                lblRL.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);
        }

        private void lblRR_Click(object sender, EventArgs e)
        {
            if (lblRR.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.RR(true);
                lblRR.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.RR(false);
                lblRR.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);
        }

        private void lblREP_Click(object sender, EventArgs e)
        {
            if (lblREP.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.REP(true);
                lblREP.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.REP(false);
                lblREP.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);
        }

        private void lblSFL_Click(object sender, EventArgs e)
        {
            if (lblSFL.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.SFL(true);
                lblSFL.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.SFL(false);
                lblSFL.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);
        }

        private void lblAlarm_Click(object sender, EventArgs e)
        {
            if (lblAlarm.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.Alarm(true);
                lblAlarm.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.Alarm(false);
                lblAlarm.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);
        }

        private void lblREC_Click(object sender, EventArgs e)
        {
            if (lblREC.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.Rec(true);
                lblREC.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.Rec(false);
                lblREC.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);
        }

        private void lblVol_Click(object sender, EventArgs e)
        {
            if (lblVol.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.Vol(true);
                lblVol.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.Vol(false);
                lblVol.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);
        }

        private void lblTime_Click(object sender, EventArgs e)
        {
            if (lblTime.BackColor == System.Drawing.Color.Gray)
            {
                IconWord = icon.Time(true);
                lblTime.BackColor = System.Drawing.Color.AntiqueWhite;
            }
            else
            {
                IconWord = icon.Time(false);
                lblTime.BackColor = System.Drawing.Color.Gray;
            }
            LCD.SendData(IconWord);

        }
        
		
		void BtnDiskOnClick(object sender, EventArgs e)
		{
			IconWord=icon.Disk(true);
			LCD.SendData(IconWord);
			
		}
		
		void BtnDiskOffClick(object sender, EventArgs e)
		{
			IconWord=icon.Disk(false);
			LCD.SendData(IconWord);
		}
		
		void BtnClearIconsClick(object sender, EventArgs e)
		{
			LCD.SendData(0x0100000000000000);
		}
	}
}
