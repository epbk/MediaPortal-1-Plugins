﻿/*
 * Created in SharpDevelop.

Copyright (C) 2007 raypan
 
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

using System;
using System.Runtime.InteropServices;
using System.Threading;
using Font;
using System.Diagnostics;


namespace iMonOEMLCD
{
	/// <summary>
	/// Send Data to the iMon(OEM) LCD 16 x 96 pixel display
	/// iMON is the registered trademark for USB IR reception device of Soungraph Co., Ltd.
	/// </summary>
	public class LCD 
	{
		
		[DllImport("sg_vfd.dll")]
		public static extern bool iMONVFD_Init(int vfdType, int resevered);
		[DllImport("sg_vfd.dll")]
		public static extern void iMONVFD_Uninit();
		[DllImport("sg_vfd.dll")]
		public static extern bool iMONVFD_IsInited();
		[DllImport("sg_vfd.dll")]
		public static extern bool iMONVFD_SetText(string szFirstLine, string szSecondLine);
		[DllImport("sg_vfd.dll")]
		public static extern  bool iMONVFD_SetEQ(int arEQValue);
		[DllImport("sg_vfd.dll")]
		public unsafe static extern  bool iMONLCD_SendData( Int64* bitMap);
		


	
		public unsafe static void SendData(Int64 data) {
			bool ret;
			ret =iMONLCD_SendData(&data);
			Debug.WriteLine(data.ToString("X16"));
			if (ret) Console.WriteLine("String {0} \tOK {1}", data.ToString("X16") , ret);
			else Console.WriteLine("String {0} \tFailed {1}", data.ToString("X16"), ret);
		//	Thread.Sleep(5);
			return ;
		}
		
		public static byte[] SendText(string Line1, string Line2){
			int k=0;
			byte [] pixel= new byte [192];
			for (int i=0; i< Math.Min(16,Line1.Length); i++) {
				char ch=Line1[i];
				int j=0;
				for ( j=5; j>=0; j--) {
					pixel[k+j] = BitReverse(Font.Font.Font8x5[(int)ch,j]);
				}
				k += 6;
			}
			k=96;  // do second line
			for (int i=0; i< Math.Min(16,Line2.Length); i++) {
				char ch=Line2[i];
				int j=0;
				for ( j=5; j>=0; j--) {
					pixel[k+j] = BitReverse(Font.Font.Font8x5[(int)ch,j]);
								}
				k += 6;
			}
			SendPixelArray(pixel);
			return pixel;
		}
		
		
		/// <summary>
		/// Send an array of 8x96x2 pixelse to the 16x96 display
		/// </summary>
		/// <param name="PixelsArray[192]">byte</param>
		/// <returns></returns>		
		public static void SendPixelArray(byte[] PixelArray){
			// Array starts from the top 8 pixels on the left, across 96 columns,
			// then the bottom 8 pixels from the left, across 96 columns.
			// Bit 7 of the first 96 bytes is the top row of the display
			// Bit 0 is the 8th row
			Int64 PixelWord=0;
			if (PixelArray.Length > 192) { Console.WriteLine("ERROR");}
			
			int DataControl = 0x20;
			
			for (int k=0; k <= 27*7;k += 7){
				PixelWord = DataControl;
				for (int i=6; i>=0 ; i--) {
					PixelWord <<= 8;
					if( (k+i) <PixelArray.Length) PixelWord += PixelArray[k+i];
				}
				if (DataControl <= 0x3B) SendData(PixelWord);
                DataControl++; 
			}
		}
		/// <summary>
		/// Displays the lines at the top and bottom, based on a bit map input
		/// </summary>
		/// <returns></returns>	
		public static void SetLinePixels(UInt32 TopLine, UInt32 BotLine,
		                            UInt32 TopProgress, UInt32 BotProgress){
			
			Int64 Data;
			//Least sig. bit is on the right
			
			Data = ((Int64) TopProgress) <<8*4;
			Data += TopLine;
			Data &= 0x00FFFFFFFFFFFFFF;
			Data += 0x1000000000000000;
			SendData(Data);
			
			Data = ((Int64) TopProgress) >>8*3;
			Data += ((Int64) BotProgress) << 8;
			Data += ((Int64) BotLine) <<8*5;
			Data &= 0x00FFFFFFFFFFFFFF;
			Data += 0x1100000000000000;
			SendData(Data);
			
			Data = ((Int64) BotLine) >> 8*2 ;
			Data += 0x1200000000000000;
			SendData(Data);
			
		}
		/// <summary>
		/// Displays the lines at the top and bottom, based on a line length
		/// </summary>
		/// <description
		/// Positive length display bar from the left, negative length displays from the right
		/// No input checking; data should range from -32 to + 32
		/// </description>
		/// <returns></returns>	
		public static void SetLineLength(int TopLine, int BotLine,
		                            int TopProgress, int BotProgress){
		
			SetLinePixels(LengthToPixels(TopLine),
			              LengthToPixels(BotLine),
			              LengthToPixels(TopProgress),
			              LengthToPixels(BotProgress));
		}
		/// <summary>
		/// Private helper to convert length of a bar to a pixel bit map
		/// </summary>
		/// <param name="Length"int></param>
		/// <returns>UInt 32Bit map equivalent of the line length</returns>	
		private static UInt32 LengthToPixels(int Length) {
			UInt32 [] PixLen = 
				{0x00,  0x00000080, 0x000000c0, 0x000000e0, 0x000000f0,
						0x000000f8, 0x000000fc, 0x000000fe, 0x000000ff,
						0x000080ff, 0x0000c0ff, 0x0000e0ff, 0x0000f0ff,
						0x0000f8ff, 0x0000fcff, 0x0000feff, 0x0000ffff,
						0x0080ffff, 0x00c0ffff, 0x00e0ffff, 0x00f0ffff,
						0x00f8ffff, 0x00fcffff, 0x00feffff, 0x00ffffff,
						0x80ffffff, 0xc0ffffff, 0xe0ffffff, 0xf0ffffff,
						0xf8ffffff, 0xfcffffff, 0xfeffffff, 0xffffffff};
						
			if (Math.Abs(Length) >32) return(0);

			if (Length >= 0) { return PixLen[Length];}
			else {	return (PixLen[32+Length] ^ 0xFFFFFFFF) ;}
		}
		
		public static void SetEQ( byte[] EqDataArray){
			// 16 sized array for single bar.
			// EqDataArray[0] 	0 -> up bars
			// 					1 -> down bars from top
			// 					2 -> expand from middle
			//					7 -> from top and bottom (maybe another code also works?
			//					are there other options??
			// EqDataArray[i] = length of bar
			
			Int64 EqData;
						
			int DataControl = 0x40;
			
			for (int k=0; k <= 3*7;k += 7){
				EqData = DataControl;
				for (int i=6; i>=0 ; i--) {
					EqData <<= 8;
					if( (k+i) <EqDataArray.Length) EqData += EqDataArray[k+i];
				}
				if (DataControl <= 0x42) SendData(EqData);
                DataControl++; 
			}
			
		}
		
		/// <summary>
		/// Clear Display
		/// Send the same intialisation sequence debugged from an iMon run
		/// </summary>
		/// <returns></returns>	
		public static void ClearDisplay(){

			SendData(0x5000000000000040);
			SendData(0x5100000000000000);
			SendData(0x0300000000000014);
			//SendData(0x0312be5800000014);  // 
			SendData(0x0200000000000000);
			SendData(0x0100000000000000);
			SendData(0x10ffffff00000000);
			SendData(0x110000ffffffffff);
			SendData(0x1200000000000000);
	//		ClearPixels();
			
		}

		public static void ClearPixels(){
			Int64 pixels;
			Console.WriteLine("Clear Pixels");
			for (Int64 i=0x20; i<= 0x3b ; i++) 
			{
				pixels = i << 56;
				SendData(pixels);
			}

		}
		
		

		/// <summary>
		/// Reverse the bits in a byte
		/// </summary>
		/// <param name="inByte">byte</param>
		/// <returns>byte</returns>
		private static byte BitReverse(byte inByte)
		{
			byte result = 0x00;
			byte mask = 0x00;

			for ( mask = 0x80; Convert.ToInt32(mask) > 0; 
                	mask >>= 1)
			{
				result >>= 1;
				byte tempbyte = (byte)(inByte & mask) ;
				if (tempbyte != 0x00)
					result |= 0x80;
			}
			return (result);
		}
		
		private static UInt32 BitReverse(UInt32 Word){
		
			UInt32 v; // 32 bit word to reverse bit order
			v=Word;
			// swap odd and even bits
			v = ((v >> 1) & 0x55555555) | ((v & 0x55555555) << 1);
			// swap consecutive pairs
			v = ((v >> 2) & 0x33333333) | ((v & 0x33333333) << 2);
			// swap nibbles ... 
			v = ((v >> 4) & 0x0F0F0F0F) | ((v & 0x0F0F0F0F) << 4);
			// swap bytes
			v = ((v >> 8) & 0x00FF00FF) | ((v & 0x00FF00FF) << 8);
			// swap 2-byte long pairs
			v = ( v >> 16             ) | ( v               << 16);
			
			return v;
		}
		

		
		
		/// <summary>
		/// Icons Class
		/// </summary>
		/// <returns>Int 64 with the icon bit set</returns>	
	public class Icons {
		private Int64 icon=0x0100000000000000;
		//Byte 6
		private Int64 DiskOff	= 0x0F00FFFFFFFFFFFF;
		private Int64 DiskOn	= 0x0080FF0000000000;
		
		// Byte 5
		private int WMA_2bit 	= 40;
		private int WAVbit 		= 39;
		private int REPbit		= 38;
		private int SFLbit		= 37;
		private int Alarmbit	= 36;
		private int Recbit 		= 35;
		private int Volbit 		= 34;
		private int Timebit 	= 33;
		// Byte 4
		private int xVidbit 	= 32;
		private int WMVbit 		= 31;
		private int MPG_2bit	= 30;
		private int AC3bit 		= 29;
		private int DTSbit 		= 28;
		private int WMAbit 		= 27;
		private int MP3bit 		= 26;
		private int OGGbit 		= 25;

		//Byte 3
		private int SRCbit		= 24;
		private int FITbit		= 23;
		private int TV_2bit		= 22;
		private int HDTVbit		= 21;
		private int SCR1bit		= 20;
		private int SCR2bit		= 19;
		private int MPGbit 		= 18;
		private int DivXbit 	= 17;
		// Byte 2
		private int Cbit		= 16;
		private int Rbit		= 15;
		private int SLbit		= 14;
		private int LFEbit		= 13;
		private int SRbit		= 12;
		private int RLbit		= 11;
		private int SPDIFbit	= 10;
		private int RRbit		= 9;
		// Byte 1
		private int Musicbit 	= 8;
		private int Moviebit 	= 7;
		private int Photobit 	= 6;
		private int CD_DVDbit 	= 5;
		private int TVbit 		= 4;
		private int WebCastbit 	= 3;
		private int Newsbit 	= 2;
		private int Lbit		= 1;

		public Int64 ClearAll()
		{
			return 0x0100000000000000;
		}
		
		public Int64 REP(bool on){
			if (on) icon=BitSet (icon, REPbit);
			else  icon=BitClear (icon, REPbit);
			return (icon);
		}

		public Int64 Alarm(bool on){
			if (on) icon=BitSet (icon, Alarmbit);
			else  icon=BitClear (icon, Alarmbit);
			return (icon);
		}

		public Int64 Rec(bool on){
			if (on) icon=BitSet (icon, Recbit);
			else  icon=BitClear (icon, Recbit);
			return (icon);
		}

		public Int64 Vol(bool on){
			if (on) icon=BitSet (icon, Volbit);
			else  icon=BitClear (icon, Volbit);
			return (icon);
		}

		public Int64 Time(bool on){
			if (on) icon=BitSet (icon, Timebit);
			else  icon=BitClear (icon, Timebit);
			return (icon);
		}

		public Int64 MPG(bool on){
			if (on) icon=BitSet (icon, MPGbit);
			else  icon=BitClear (icon, MPGbit);
			return (icon);
		}

		public Int64 DivX(bool on){
			if (on) icon=BitSet (icon, DivXbit);
			else  icon=BitClear (icon, DivXbit);
			return (icon);
		}

		public Int64 xVid(bool on){
			if (on) icon=BitSet (icon, xVidbit);
			else  icon=BitClear (icon, xVidbit);
			return (icon);
		}

		public Int64 WMV(bool on){
			if (on) icon=BitSet (icon, WMVbit);
			else  icon=BitClear (icon, WMVbit);
			return (icon);
		}

		public Int64 MPG_2(bool on){
			if (on) icon=BitSet (icon, MPG_2bit);
			else  icon=BitClear (icon, MPG_2bit);
			return (icon);
		}

		public Int64 AC3(bool on){
			if (on) icon=BitSet (icon, AC3bit);
			else  icon=BitClear (icon, AC3bit);
			return (icon);
		}

		public Int64 DTS(bool on){
			if (on) icon=BitSet (icon, DTSbit);
			else  icon=BitClear (icon, DTSbit);
			return (icon);
		}

		public Int64 WMA(bool on){
			if (on) icon=BitSet (icon, WMAbit);
			else  icon=BitClear (icon, WMAbit);
			return (icon);
		}

		public Int64 MP3(bool on){
			if (on) icon=BitSet (icon, MP3bit);
			else  icon=BitClear (icon, MP3bit);
			return (icon);
		}	

		public Int64 OGG(bool on){
			if (on) icon=BitSet (icon, OGGbit);
			else  icon=BitClear (icon, OGGbit);
			return (icon);
		}

		public Int64 WMA_2(bool on){
			if (on) icon=BitSet (icon, WMA_2bit);
			else  icon=BitClear (icon, WMA_2bit);
			return (icon);
		}

		public Int64 WAV(bool on){
			if (on) icon=BitSet (icon, WAVbit);
			else  icon=BitClear (icon, WAVbit);
			return (icon);
		}

		public Int64 Music(bool on){
			if (on) icon=BitSet (icon, Musicbit);
			else  icon=BitClear (icon, Musicbit);
			return (icon);
		}

		public Int64 Movie(bool on){
			if (on) icon=BitSet (icon, Moviebit);
			else  icon=BitClear (icon, Moviebit);
			return (icon);
		}

		public Int64 Photo(bool on){
			if (on) icon=BitSet (icon, Photobit);
			else  icon=BitClear (icon, Photobit);
			return (icon);
		}

		public Int64 CD_DVD(bool on){
			if (on) icon=BitSet (icon, CD_DVDbit);
			else  icon=BitClear (icon, CD_DVDbit);
			return (icon);
		}

		public Int64 TV(bool on){
			if (on) icon=BitSet (icon, TVbit);
			else  icon=BitClear (icon, TVbit);
			return (icon);
		}

		public Int64 WebCast(bool on){
			if (on) icon=BitSet (icon, WebCastbit);
			else  icon=BitClear (icon, WebCastbit);
			return (icon);
		}

		public Int64 News(bool on){
			if (on) icon=BitSet (icon, Newsbit);
			else  icon=BitClear (icon, Newsbit);
			return (icon);
		}

		public Int64 Centre(bool on){
			if (on) icon=BitSet (icon, Cbit);
			else  icon=BitClear (icon, Cbit);
			return (icon);
		}
			
		public Int64 LFE(bool on){
			if (on) icon=BitSet (icon, LFEbit);
			else  icon=BitClear (icon, LFEbit);
			return (icon);
		}

		public Int64 Left(bool on){
			if (on) icon=BitSet (icon, Lbit);
			else  icon=BitClear (icon, Lbit);
			return (icon);
		}

		public Int64 Right(bool on){
			if (on) icon=BitSet (icon, Rbit);
			else  icon=BitClear (icon, Rbit);
			return (icon);
		}

		public Int64 RL(bool on){
			if (on) icon=BitSet (icon, RLbit);
			else  icon=BitClear (icon, RLbit);
			return (icon);
		}
		
		public Int64 RR(bool on){
			if (on) icon=BitSet (icon, RRbit);
			else  icon=BitClear (icon, RRbit);
			return (icon);
		}

		public Int64 SCR1(bool on){
			if (on) icon=BitSet (icon, SCR1bit);
			else  icon=BitClear (icon, SCR1bit);
			return (icon);
		}

		public Int64 SCR2(bool on){
			if (on) icon=BitSet (icon, SCR2bit);
			else  icon=BitClear (icon, SCR2bit);
			return (icon);
		}
		
		public Int64 HDTV(bool on){
			if (on) icon=BitSet (icon, HDTVbit);
			else  icon=BitClear (icon, HDTVbit);
			return (icon);
		}

		public Int64 SFL(bool on){
			if (on) icon=BitSet (icon, SFLbit);
			else  icon=BitClear (icon, SFLbit);
			return (icon);
		}
		public Int64 SRC(bool on){
			if (on) icon=BitSet (icon, SRCbit);
			else  icon=BitClear (icon, SRCbit);
			return (icon);
		}

		public Int64 FIT(bool on){
			if (on) icon=BitSet (icon, FITbit);
			else  icon=BitClear (icon, FITbit);
			return (icon);
		}

		public Int64 TV_2(bool on){
			if (on) icon=BitSet (icon, TV_2bit);
			else  icon=BitClear (icon, TV_2bit);
			return (icon);
		}

		public Int64 SL(bool on){
			if (on) icon=BitSet (icon, SLbit);
			else  icon=BitClear (icon, SLbit);
			return (icon);
		}

		public Int64 SR(bool on){
			if (on) icon=BitSet (icon, SRbit);
			else  icon=BitClear (icon, SRbit);
			return (icon);
		}

		public Int64 SPDIF(bool on){
			if (on) icon=BitSet (icon, SPDIFbit);
			else  icon=BitClear (icon, SPDIFbit);
			return (icon);
		}

		public Int64 Disk(bool on){
			if (on) icon|=DiskOn;
			else  icon &= DiskOff;
			return (icon);
		}

		
		public Int64 DiskIcon(bool on){
			//TODO
		//	if (on) icon	|= 0x000F880000000000;
		//	else icon 		&= 0xFF0000FFFFFFFFFF;
			return (icon);
		}
	

		public Int64 DiskSpin(int Position){
			//TODO
		//	if (on) icon	|= 0x000F880000000000;
		//	else icon 		&= 0xFF0000FFFFFFFFFF;
			return (icon);
		}	

	
#region Bit Helpers
		/// <summary>
		/// Sets a bit
		/// </summary>
		/// <param name="Source">The source long.</param>
		/// <param name="bit">Which Bit to set</param>
		/// <returns></returns>
		private static Int64 BitSet ( Int64 Source, int bit )
		{
		//	Int64 temp;
		//	temp = BitClear(Source,bit);
			
			Int64 mask=1; 
			mask = mask << bit-1;
			Debug.WriteLine ("bit set {0}",(Source|mask).ToString("X16"));
			return Source | mask;
		}

		/// <summary>
		/// Clears a bit
		/// </summary>
		/// <param name="Source">The source long.</param>
		/// <param name="bit">Which Bit to clear</param>
		/// <returns></returns>
		private static Int64 BitClear ( Int64 Source, int bit )
		{
			Int64 mask=1; 
			mask = mask << bit-1;
			mask ^= 0x0FFFFFFFFFFFFFFF;
			Debug.WriteLine("Bit Clear {0}",(Source & mask).ToString("X16"));
			return Source & mask;
		}
	

#endregion

	}
}

	
}
