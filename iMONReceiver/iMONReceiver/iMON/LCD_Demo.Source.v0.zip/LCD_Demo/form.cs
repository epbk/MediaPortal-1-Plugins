﻿/*
 * Created by SharpDevelop.
 * User: ryouie
 * Date: 14/06/2007
 * Time: 11:37 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;
using System.Drawing;
using System.Windows.Forms;

namespace DefaultNamespace
{
	/// <summary>
	/// Description of Form1.
	/// </summary>
	public partial class Form1 : Form
	{
		public Form1()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void NumericUpDown1ValueChanged(object sender, EventArgs e)
		{
			textBox1.value=NumericUpDown1.value;
			
		}
	}
}
