﻿/*
 * Created by SharpDevelop.
 * User: raypan
 * Date: 17/06/2007
 * Time: 11:11 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace LCD_Demo
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtFirstLine = new System.Windows.Forms.TextBox();
			this.txtSecondLine = new System.Windows.Forms.TextBox();
			this.btnSend = new System.Windows.Forms.Button();
			this.btnScrollLines = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.lblMusic = new System.Windows.Forms.Label();
			this.lblMovie = new System.Windows.Forms.Label();
			this.lblPhoto = new System.Windows.Forms.Label();
			this.lblCD_DVD = new System.Windows.Forms.Label();
			this.lblWeb = new System.Windows.Forms.Label();
			this.lblNews = new System.Windows.Forms.Label();
			this.btnExit = new System.Windows.Forms.Button();
			this.lblMPG = new System.Windows.Forms.Label();
			this.lblDivX = new System.Windows.Forms.Label();
			this.lblXVid = new System.Windows.Forms.Label();
			this.lblWMV = new System.Windows.Forms.Label();
			this.lblMPG_2 = new System.Windows.Forms.Label();
			this.lblAC3 = new System.Windows.Forms.Label();
			this.lblDTS = new System.Windows.Forms.Label();
			this.lblWMA = new System.Windows.Forms.Label();
			this.lblMP3 = new System.Windows.Forms.Label();
			this.lblOGG = new System.Windows.Forms.Label();
			this.lblWMA_2 = new System.Windows.Forms.Label();
			this.lblWAV = new System.Windows.Forms.Label();
			this.lblTV = new System.Windows.Forms.Label();
			this.btnClearIcons = new System.Windows.Forms.Button();
			this.lblSRC = new System.Windows.Forms.Label();
			this.lblHDTV = new System.Windows.Forms.Label();
			this.lblSCR1 = new System.Windows.Forms.Label();
			this.lblTV_2 = new System.Windows.Forms.Label();
			this.lblFIT = new System.Windows.Forms.Label();
			this.lblSCR2 = new System.Windows.Forms.Label();
			this.lblL = new System.Windows.Forms.Label();
			this.lblR = new System.Windows.Forms.Label();
			this.lblC = new System.Windows.Forms.Label();
			this.lblSL = new System.Windows.Forms.Label();
			this.lblLFE = new System.Windows.Forms.Label();
			this.lblSR = new System.Windows.Forms.Label();
			this.lblSPDIF = new System.Windows.Forms.Label();
			this.lblRL = new System.Windows.Forms.Label();
			this.lblRR = new System.Windows.Forms.Label();
			this.lblREP = new System.Windows.Forms.Label();
			this.lblSFL = new System.Windows.Forms.Label();
			this.lblAlarm = new System.Windows.Forms.Label();
			this.lblREC = new System.Windows.Forms.Label();
			this.lblVol = new System.Windows.Forms.Label();
			this.lblTime = new System.Windows.Forms.Label();
			this.btnDiskOn = new System.Windows.Forms.Button();
			this.btnDiskOff = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.radioButton4 = new System.Windows.Forms.RadioButton();
			this.radioButton3 = new System.Windows.Forms.RadioButton();
			this.radioButton2 = new System.Windows.Forms.RadioButton();
			this.radioButton1 = new System.Windows.Forms.RadioButton();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// txtFirstLine
			// 
			this.txtFirstLine.Location = new System.Drawing.Point(148, 105);
			this.txtFirstLine.Name = "txtFirstLine";
			this.txtFirstLine.Size = new System.Drawing.Size(220, 20);
			this.txtFirstLine.TabIndex = 0;
			this.txtFirstLine.Text = "SoundGraph";
			this.txtFirstLine.TextChanged += new System.EventHandler(this.TxtFirstLineTextChanged);
			// 
			// txtSecondLine
			// 
			this.txtSecondLine.Location = new System.Drawing.Point(148, 131);
			this.txtSecondLine.Name = "txtSecondLine";
			this.txtSecondLine.Size = new System.Drawing.Size(220, 20);
			this.txtSecondLine.TabIndex = 1;
			this.txtSecondLine.Text = "OEM LCD Demo";
			this.txtSecondLine.TextChanged += new System.EventHandler(this.TxtSecondLineTextChanged);
			// 
			// btnSend
			// 
			this.btnSend.Location = new System.Drawing.Point(15, 16);
			this.btnSend.Name = "btnSend";
			this.btnSend.Size = new System.Drawing.Size(75, 41);
			this.btnSend.TabIndex = 2;
			this.btnSend.Text = "Graphic EQ Demo";
			this.btnSend.UseVisualStyleBackColor = true;
			this.btnSend.Click += new System.EventHandler(this.BtnSendClick);
			// 
			// btnScrollLines
			// 
			this.btnScrollLines.Location = new System.Drawing.Point(148, 43);
			this.btnScrollLines.Name = "btnScrollLines";
			this.btnScrollLines.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.btnScrollLines.Size = new System.Drawing.Size(220, 23);
			this.btnScrollLines.TabIndex = 3;
			this.btnScrollLines.Text = "Scroll Lines";
			this.btnScrollLines.UseVisualStyleBackColor = true;
			this.btnScrollLines.Click += new System.EventHandler(this.BtnScrollLinesClick);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(169, 81);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(174, 21);
			this.label1.TabIndex = 4;
			this.label1.Text = "(Maximum 16 Characters)";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblMusic
			// 
			this.lblMusic.BackColor = System.Drawing.Color.Gray;
			this.lblMusic.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblMusic.Location = new System.Drawing.Point(63, 11);
			this.lblMusic.Name = "lblMusic";
			this.lblMusic.Size = new System.Drawing.Size(47, 18);
			this.lblMusic.TabIndex = 5;
			this.lblMusic.Text = "MUSIC";
			this.lblMusic.MouseClick += new System.Windows.Forms.MouseEventHandler(this.LblMusicMouseClick);
			// 
			// lblMovie
			// 
			this.lblMovie.BackColor = System.Drawing.Color.Gray;
			this.lblMovie.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblMovie.Location = new System.Drawing.Point(116, 11);
			this.lblMovie.Name = "lblMovie";
			this.lblMovie.Size = new System.Drawing.Size(47, 18);
			this.lblMovie.TabIndex = 6;
			this.lblMovie.Text = "MOVIE";
			this.lblMovie.MouseClick += new System.Windows.Forms.MouseEventHandler(this.LblMovieMouseClick);
			// 
			// lblPhoto
			// 
			this.lblPhoto.BackColor = System.Drawing.Color.Gray;
			this.lblPhoto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblPhoto.Location = new System.Drawing.Point(169, 11);
			this.lblPhoto.Name = "lblPhoto";
			this.lblPhoto.Size = new System.Drawing.Size(47, 18);
			this.lblPhoto.TabIndex = 7;
			this.lblPhoto.Text = "PHOTO";
			this.lblPhoto.MouseClick += new System.Windows.Forms.MouseEventHandler(this.LblPhotoMouseClick);
			// 
			// lblCD_DVD
			// 
			this.lblCD_DVD.BackColor = System.Drawing.Color.Gray;
			this.lblCD_DVD.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblCD_DVD.Location = new System.Drawing.Point(222, 11);
			this.lblCD_DVD.Name = "lblCD_DVD";
			this.lblCD_DVD.Size = new System.Drawing.Size(52, 18);
			this.lblCD_DVD.TabIndex = 8;
			this.lblCD_DVD.Text = "CD/DVD";
			this.lblCD_DVD.MouseClick += new System.Windows.Forms.MouseEventHandler(this.LblCD_DVDMouseClick);
			// 
			// lblWeb
			// 
			this.lblWeb.BackColor = System.Drawing.Color.Gray;
			this.lblWeb.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblWeb.Location = new System.Drawing.Point(305, 11);
			this.lblWeb.Name = "lblWeb";
			this.lblWeb.Size = new System.Drawing.Size(63, 18);
			this.lblWeb.TabIndex = 10;
			this.lblWeb.Text = "WEBCast";
			this.lblWeb.MouseClick += new System.Windows.Forms.MouseEventHandler(this.LblWebMouseClick);
			// 
			// lblNews
			// 
			this.lblNews.BackColor = System.Drawing.Color.Gray;
			this.lblNews.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblNews.Location = new System.Drawing.Point(374, 11);
			this.lblNews.Name = "lblNews";
			this.lblNews.Size = new System.Drawing.Size(47, 18);
			this.lblNews.TabIndex = 11;
			this.lblNews.Text = "NEWS";
			this.lblNews.MouseClick += new System.Windows.Forms.MouseEventHandler(this.LblNewsMouseClick);
			// 
			// btnExit
			// 
			this.btnExit.Location = new System.Drawing.Point(519, 226);
			this.btnExit.Name = "btnExit";
			this.btnExit.Size = new System.Drawing.Size(75, 23);
			this.btnExit.TabIndex = 12;
			this.btnExit.Text = "Exit";
			this.btnExit.UseVisualStyleBackColor = true;
			this.btnExit.Click += new System.EventHandler(this.BtnExitClick);
			// 
			// lblMPG
			// 
			this.lblMPG.BackColor = System.Drawing.Color.Gray;
			this.lblMPG.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblMPG.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblMPG.Location = new System.Drawing.Point(38, 175);
			this.lblMPG.Name = "lblMPG";
			this.lblMPG.Size = new System.Drawing.Size(34, 18);
			this.lblMPG.TabIndex = 13;
			this.lblMPG.Text = "MPG";
			this.lblMPG.Click += new System.EventHandler(this.LblMPGClick);
			// 
			// lblDivX
			// 
			this.lblDivX.BackColor = System.Drawing.Color.Gray;
			this.lblDivX.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblDivX.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblDivX.Location = new System.Drawing.Point(78, 175);
			this.lblDivX.Name = "lblDivX";
			this.lblDivX.Size = new System.Drawing.Size(34, 18);
			this.lblDivX.TabIndex = 14;
			this.lblDivX.Text = "DIVX";
			this.lblDivX.Click += new System.EventHandler(this.LblDivXClick);
			// 
			// lblXVid
			// 
			this.lblXVid.BackColor = System.Drawing.Color.Gray;
			this.lblXVid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblXVid.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblXVid.Location = new System.Drawing.Point(118, 175);
			this.lblXVid.Name = "lblXVid";
			this.lblXVid.Size = new System.Drawing.Size(34, 18);
			this.lblXVid.TabIndex = 15;
			this.lblXVid.Text = "XVID";
			this.lblXVid.Click += new System.EventHandler(this.LblXVidClick);
			// 
			// lblWMV
			// 
			this.lblWMV.BackColor = System.Drawing.Color.Gray;
			this.lblWMV.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblWMV.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblWMV.Location = new System.Drawing.Point(158, 175);
			this.lblWMV.Name = "lblWMV";
			this.lblWMV.Size = new System.Drawing.Size(34, 18);
			this.lblWMV.TabIndex = 16;
			this.lblWMV.Text = "WMV";
			this.lblWMV.Click += new System.EventHandler(this.LblWMVClick);
			// 
			// lblMPG_2
			// 
			this.lblMPG_2.BackColor = System.Drawing.Color.Gray;
			this.lblMPG_2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblMPG_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblMPG_2.Location = new System.Drawing.Point(197, 175);
			this.lblMPG_2.Name = "lblMPG_2";
			this.lblMPG_2.Size = new System.Drawing.Size(34, 18);
			this.lblMPG_2.TabIndex = 17;
			this.lblMPG_2.Text = "MPG";
			this.lblMPG_2.Click += new System.EventHandler(this.LblMPG_2Click);
			// 
			// lblAC3
			// 
			this.lblAC3.BackColor = System.Drawing.Color.Gray;
			this.lblAC3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblAC3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAC3.Location = new System.Drawing.Point(237, 175);
			this.lblAC3.Name = "lblAC3";
			this.lblAC3.Size = new System.Drawing.Size(34, 18);
			this.lblAC3.TabIndex = 18;
			this.lblAC3.Text = "AC3";
			this.lblAC3.Click += new System.EventHandler(this.LblAC3Click);
			// 
			// lblDTS
			// 
			this.lblDTS.BackColor = System.Drawing.Color.Gray;
			this.lblDTS.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblDTS.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblDTS.Location = new System.Drawing.Point(277, 175);
			this.lblDTS.Name = "lblDTS";
			this.lblDTS.Size = new System.Drawing.Size(34, 18);
			this.lblDTS.TabIndex = 19;
			this.lblDTS.Text = "DTS";
			this.lblDTS.Click += new System.EventHandler(this.LblDTSClick);
			// 
			// lblWMA
			// 
			this.lblWMA.BackColor = System.Drawing.Color.Gray;
			this.lblWMA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblWMA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblWMA.Location = new System.Drawing.Point(317, 175);
			this.lblWMA.Name = "lblWMA";
			this.lblWMA.Size = new System.Drawing.Size(34, 18);
			this.lblWMA.TabIndex = 20;
			this.lblWMA.Text = "WMA";
			this.lblWMA.Click += new System.EventHandler(this.LblWMAClick);
			// 
			// lblMP3
			// 
			this.lblMP3.BackColor = System.Drawing.Color.Gray;
			this.lblMP3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblMP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblMP3.Location = new System.Drawing.Point(357, 175);
			this.lblMP3.Name = "lblMP3";
			this.lblMP3.Size = new System.Drawing.Size(34, 18);
			this.lblMP3.TabIndex = 21;
			this.lblMP3.Text = "MP3";
			this.lblMP3.Click += new System.EventHandler(this.LblMP3Click);
			// 
			// lblOGG
			// 
			this.lblOGG.BackColor = System.Drawing.Color.Gray;
			this.lblOGG.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblOGG.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblOGG.Location = new System.Drawing.Point(397, 175);
			this.lblOGG.Name = "lblOGG";
			this.lblOGG.Size = new System.Drawing.Size(34, 18);
			this.lblOGG.TabIndex = 22;
			this.lblOGG.Text = "OGG";
			this.lblOGG.Click += new System.EventHandler(this.LblOGGClick);
			// 
			// lblWMA_2
			// 
			this.lblWMA_2.BackColor = System.Drawing.Color.Gray;
			this.lblWMA_2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblWMA_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblWMA_2.Location = new System.Drawing.Point(437, 175);
			this.lblWMA_2.Name = "lblWMA_2";
			this.lblWMA_2.Size = new System.Drawing.Size(34, 18);
			this.lblWMA_2.TabIndex = 23;
			this.lblWMA_2.Text = "WMA";
			this.lblWMA_2.Click += new System.EventHandler(this.LblWMA_2Click);
			// 
			// lblWAV
			// 
			this.lblWAV.BackColor = System.Drawing.Color.Gray;
			this.lblWAV.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblWAV.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblWAV.Location = new System.Drawing.Point(477, 175);
			this.lblWAV.Name = "lblWAV";
			this.lblWAV.Size = new System.Drawing.Size(34, 18);
			this.lblWAV.TabIndex = 24;
			this.lblWAV.Text = "WAV";
			this.lblWAV.Click += new System.EventHandler(this.LblWAVClick);
			// 
			// lblTV
			// 
			this.lblTV.BackColor = System.Drawing.Color.Gray;
			this.lblTV.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblTV.Location = new System.Drawing.Point(277, 11);
			this.lblTV.Name = "lblTV";
			this.lblTV.Size = new System.Drawing.Size(34, 18);
			this.lblTV.TabIndex = 25;
			this.lblTV.Text = "TV";
			this.lblTV.Click += new System.EventHandler(this.LblTVClick);
			// 
			// btnClearIcons
			// 
			this.btnClearIcons.Location = new System.Drawing.Point(35, 226);
			this.btnClearIcons.Name = "btnClearIcons";
			this.btnClearIcons.Size = new System.Drawing.Size(75, 23);
			this.btnClearIcons.TabIndex = 26;
			this.btnClearIcons.Text = "Clear Icons";
			this.btnClearIcons.UseVisualStyleBackColor = true;
			this.btnClearIcons.Click += new System.EventHandler(this.BtnClearIconsClick);
			// 
			// lblSRC
			// 
			this.lblSRC.BackColor = System.Drawing.Color.Gray;
			this.lblSRC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblSRC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblSRC.Location = new System.Drawing.Point(424, 105);
			this.lblSRC.Name = "lblSRC";
			this.lblSRC.Size = new System.Drawing.Size(47, 18);
			this.lblSRC.TabIndex = 27;
			this.lblSRC.Text = "SRC";
			this.lblSRC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblSRC.Click += new System.EventHandler(this.lblSRC_Click);
			// 
			// lblHDTV
			// 
			this.lblHDTV.BackColor = System.Drawing.Color.Gray;
			this.lblHDTV.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblHDTV.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblHDTV.Location = new System.Drawing.Point(477, 123);
			this.lblHDTV.Name = "lblHDTV";
			this.lblHDTV.Size = new System.Drawing.Size(47, 18);
			this.lblHDTV.TabIndex = 28;
			this.lblHDTV.Text = "HDTV";
			this.lblHDTV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblHDTV.Click += new System.EventHandler(this.lblHDTV_Click);
			// 
			// lblSCR1
			// 
			this.lblSCR1.BackColor = System.Drawing.Color.Gray;
			this.lblSCR1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblSCR1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblSCR1.Location = new System.Drawing.Point(424, 141);
			this.lblSCR1.Name = "lblSCR1";
			this.lblSCR1.Size = new System.Drawing.Size(47, 18);
			this.lblSCR1.TabIndex = 29;
			this.lblSCR1.Text = "SCR1";
			this.lblSCR1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblSCR1.Click += new System.EventHandler(this.lblSCCR1_Click);
			// 
			// lblTV_2
			// 
			this.lblTV_2.BackColor = System.Drawing.Color.Gray;
			this.lblTV_2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblTV_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTV_2.Location = new System.Drawing.Point(424, 123);
			this.lblTV_2.Name = "lblTV_2";
			this.lblTV_2.Size = new System.Drawing.Size(47, 18);
			this.lblTV_2.TabIndex = 30;
			this.lblTV_2.Text = "TV";
			this.lblTV_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblTV_2.Click += new System.EventHandler(this.lblTV_2_Click);
			// 
			// lblFIT
			// 
			this.lblFIT.BackColor = System.Drawing.Color.Gray;
			this.lblFIT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblFIT.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFIT.Location = new System.Drawing.Point(477, 105);
			this.lblFIT.Name = "lblFIT";
			this.lblFIT.Size = new System.Drawing.Size(47, 18);
			this.lblFIT.TabIndex = 31;
			this.lblFIT.Text = "FIT";
			this.lblFIT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblFIT.Click += new System.EventHandler(this.lblFIT_Click);
			// 
			// lblSCR2
			// 
			this.lblSCR2.BackColor = System.Drawing.Color.Gray;
			this.lblSCR2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblSCR2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblSCR2.Location = new System.Drawing.Point(477, 141);
			this.lblSCR2.Name = "lblSCR2";
			this.lblSCR2.Size = new System.Drawing.Size(47, 18);
			this.lblSCR2.TabIndex = 32;
			this.lblSCR2.Text = "SCR2";
			this.lblSCR2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblSCR2.Click += new System.EventHandler(this.lblSCR2_Click);
			// 
			// lblL
			// 
			this.lblL.BackColor = System.Drawing.Color.Gray;
			this.lblL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblL.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblL.Location = new System.Drawing.Point(437, 11);
			this.lblL.Name = "lblL";
			this.lblL.Size = new System.Drawing.Size(34, 18);
			this.lblL.TabIndex = 33;
			this.lblL.Text = "L";
			this.lblL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblL.Click += new System.EventHandler(this.lblL_Click);
			// 
			// lblR
			// 
			this.lblR.BackColor = System.Drawing.Color.Gray;
			this.lblR.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblR.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblR.Location = new System.Drawing.Point(517, 11);
			this.lblR.Name = "lblR";
			this.lblR.Size = new System.Drawing.Size(34, 18);
			this.lblR.TabIndex = 34;
			this.lblR.Text = "R";
			this.lblR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblR.Click += new System.EventHandler(this.lblR_Click);
			// 
			// lblC
			// 
			this.lblC.BackColor = System.Drawing.Color.Gray;
			this.lblC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblC.Location = new System.Drawing.Point(477, 11);
			this.lblC.Name = "lblC";
			this.lblC.Size = new System.Drawing.Size(34, 18);
			this.lblC.TabIndex = 35;
			this.lblC.Text = "C";
			this.lblC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblC.Click += new System.EventHandler(this.lblC_Click);
			// 
			// lblSL
			// 
			this.lblSL.BackColor = System.Drawing.Color.Gray;
			this.lblSL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblSL.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblSL.Location = new System.Drawing.Point(437, 29);
			this.lblSL.Name = "lblSL";
			this.lblSL.Size = new System.Drawing.Size(34, 18);
			this.lblSL.TabIndex = 36;
			this.lblSL.Text = "SL";
			this.lblSL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblSL.Click += new System.EventHandler(this.lblSL_Click);
			// 
			// lblLFE
			// 
			this.lblLFE.BackColor = System.Drawing.Color.Gray;
			this.lblLFE.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblLFE.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblLFE.Location = new System.Drawing.Point(477, 29);
			this.lblLFE.Name = "lblLFE";
			this.lblLFE.Size = new System.Drawing.Size(34, 18);
			this.lblLFE.TabIndex = 37;
			this.lblLFE.Text = "LFE";
			this.lblLFE.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblLFE.Click += new System.EventHandler(this.lblLFE_Click);
			// 
			// lblSR
			// 
			this.lblSR.BackColor = System.Drawing.Color.Gray;
			this.lblSR.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblSR.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblSR.Location = new System.Drawing.Point(517, 29);
			this.lblSR.Name = "lblSR";
			this.lblSR.Size = new System.Drawing.Size(34, 18);
			this.lblSR.TabIndex = 38;
			this.lblSR.Text = "SR";
			this.lblSR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblSR.Click += new System.EventHandler(this.lblSR_Click);
			// 
			// lblSPDIF
			// 
			this.lblSPDIF.BackColor = System.Drawing.Color.Gray;
			this.lblSPDIF.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblSPDIF.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblSPDIF.Location = new System.Drawing.Point(477, 48);
			this.lblSPDIF.Name = "lblSPDIF";
			this.lblSPDIF.Size = new System.Drawing.Size(34, 18);
			this.lblSPDIF.TabIndex = 39;
			this.lblSPDIF.Text = "SPDIF";
			this.lblSPDIF.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblSPDIF.Click += new System.EventHandler(this.lblSPDIF_Click);
			// 
			// lblRL
			// 
			this.lblRL.BackColor = System.Drawing.Color.Gray;
			this.lblRL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblRL.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblRL.Location = new System.Drawing.Point(437, 48);
			this.lblRL.Name = "lblRL";
			this.lblRL.Size = new System.Drawing.Size(34, 18);
			this.lblRL.TabIndex = 40;
			this.lblRL.Text = "RL";
			this.lblRL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblRL.Click += new System.EventHandler(this.lblRL_Click);
			// 
			// lblRR
			// 
			this.lblRR.BackColor = System.Drawing.Color.Gray;
			this.lblRR.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblRR.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblRR.Location = new System.Drawing.Point(517, 48);
			this.lblRR.Name = "lblRR";
			this.lblRR.Size = new System.Drawing.Size(34, 18);
			this.lblRR.TabIndex = 41;
			this.lblRR.Text = "RR";
			this.lblRR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblRR.Click += new System.EventHandler(this.lblRR_Click);
			// 
			// lblREP
			// 
			this.lblREP.BackColor = System.Drawing.Color.Gray;
			this.lblREP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblREP.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblREP.Location = new System.Drawing.Point(36, 84);
			this.lblREP.Name = "lblREP";
			this.lblREP.Size = new System.Drawing.Size(34, 18);
			this.lblREP.TabIndex = 42;
			this.lblREP.Text = "REP";
			this.lblREP.Click += new System.EventHandler(this.lblREP_Click);
			// 
			// lblSFL
			// 
			this.lblSFL.BackColor = System.Drawing.Color.Gray;
			this.lblSFL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblSFL.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblSFL.Location = new System.Drawing.Point(90, 84);
			this.lblSFL.Name = "lblSFL";
			this.lblSFL.Size = new System.Drawing.Size(34, 18);
			this.lblSFL.TabIndex = 43;
			this.lblSFL.Text = "SFL";
			this.lblSFL.Click += new System.EventHandler(this.lblSFL_Click);
			// 
			// lblAlarm
			// 
			this.lblAlarm.BackColor = System.Drawing.Color.Gray;
			this.lblAlarm.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblAlarm.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAlarm.Location = new System.Drawing.Point(36, 107);
			this.lblAlarm.Name = "lblAlarm";
			this.lblAlarm.Size = new System.Drawing.Size(48, 18);
			this.lblAlarm.TabIndex = 44;
			this.lblAlarm.Text = "ALARM";
			this.lblAlarm.Click += new System.EventHandler(this.lblAlarm_Click);
			// 
			// lblREC
			// 
			this.lblREC.BackColor = System.Drawing.Color.Gray;
			this.lblREC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblREC.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblREC.Location = new System.Drawing.Point(90, 107);
			this.lblREC.Name = "lblREC";
			this.lblREC.Size = new System.Drawing.Size(34, 18);
			this.lblREC.TabIndex = 45;
			this.lblREC.Text = "REC";
			this.lblREC.Click += new System.EventHandler(this.lblREC_Click);
			// 
			// lblVol
			// 
			this.lblVol.BackColor = System.Drawing.Color.Gray;
			this.lblVol.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblVol.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblVol.Location = new System.Drawing.Point(38, 131);
			this.lblVol.Name = "lblVol";
			this.lblVol.Size = new System.Drawing.Size(34, 18);
			this.lblVol.TabIndex = 46;
			this.lblVol.Text = "VOL";
			this.lblVol.Click += new System.EventHandler(this.lblVol_Click);
			// 
			// lblTime
			// 
			this.lblTime.BackColor = System.Drawing.Color.Gray;
			this.lblTime.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTime.Location = new System.Drawing.Point(90, 131);
			this.lblTime.Name = "lblTime";
			this.lblTime.Size = new System.Drawing.Size(34, 18);
			this.lblTime.TabIndex = 47;
			this.lblTime.Text = "TIME";
			this.lblTime.Click += new System.EventHandler(this.lblTime_Click);
			// 
			// btnDiskOn
			// 
			this.btnDiskOn.Location = new System.Drawing.Point(36, 32);
			this.btnDiskOn.Name = "btnDiskOn";
			this.btnDiskOn.Size = new System.Drawing.Size(75, 23);
			this.btnDiskOn.TabIndex = 48;
			this.btnDiskOn.Text = "DiskOn";
			this.btnDiskOn.UseVisualStyleBackColor = true;
			this.btnDiskOn.Click += new System.EventHandler(this.BtnDiskOnClick);
			// 
			// btnDiskOff
			// 
			this.btnDiskOff.Location = new System.Drawing.Point(35, 58);
			this.btnDiskOff.Name = "btnDiskOff";
			this.btnDiskOff.Size = new System.Drawing.Size(75, 23);
			this.btnDiskOff.TabIndex = 49;
			this.btnDiskOff.Text = "DiskOff";
			this.btnDiskOff.UseVisualStyleBackColor = true;
			this.btnDiskOff.Click += new System.EventHandler(this.BtnDiskOffClick);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.radioButton4);
			this.groupBox1.Controls.Add(this.radioButton3);
			this.groupBox1.Controls.Add(this.radioButton2);
			this.groupBox1.Controls.Add(this.radioButton1);
			this.groupBox1.Controls.Add(this.btnSend);
			this.groupBox1.Location = new System.Drawing.Point(118, 207);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(385, 80);
			this.groupBox1.TabIndex = 50;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "groupBox1";
			// 
			// radioButton4
			// 
			this.radioButton4.Location = new System.Drawing.Point(231, 33);
			this.radioButton4.Name = "radioButton4";
			this.radioButton4.Size = new System.Drawing.Size(104, 24);
			this.radioButton4.TabIndex = 6;
			this.radioButton4.Text = "Bars to Middle";
			this.radioButton4.UseVisualStyleBackColor = true;
			// 
			// radioButton3
			// 
			this.radioButton3.Location = new System.Drawing.Point(231, 13);
			this.radioButton3.Name = "radioButton3";
			this.radioButton3.Size = new System.Drawing.Size(104, 24);
			this.radioButton3.TabIndex = 5;
			this.radioButton3.Text = "Bars from Middle";
			this.radioButton3.UseVisualStyleBackColor = true;
			// 
			// radioButton2
			// 
			this.radioButton2.Location = new System.Drawing.Point(111, 33);
			this.radioButton2.Name = "radioButton2";
			this.radioButton2.Size = new System.Drawing.Size(104, 24);
			this.radioButton2.TabIndex = 4;
			this.radioButton2.Text = "Bars from Top";
			this.radioButton2.UseVisualStyleBackColor = true;
			// 
			// radioButton1
			// 
			this.radioButton1.Checked = true;
			this.radioButton1.Location = new System.Drawing.Point(111, 13);
			this.radioButton1.Name = "radioButton1";
			this.radioButton1.Size = new System.Drawing.Size(131, 24);
			this.radioButton1.TabIndex = 3;
			this.radioButton1.TabStop = true;
			this.radioButton1.Text = "Bars from Bottom";
			this.radioButton1.UseVisualStyleBackColor = true;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ClientSize = new System.Drawing.Size(606, 288);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.btnDiskOff);
			this.Controls.Add(this.btnDiskOn);
			this.Controls.Add(this.lblTime);
			this.Controls.Add(this.lblVol);
			this.Controls.Add(this.lblREC);
			this.Controls.Add(this.lblAlarm);
			this.Controls.Add(this.lblSFL);
			this.Controls.Add(this.lblREP);
			this.Controls.Add(this.lblRR);
			this.Controls.Add(this.lblRL);
			this.Controls.Add(this.lblSPDIF);
			this.Controls.Add(this.lblSR);
			this.Controls.Add(this.lblLFE);
			this.Controls.Add(this.lblSL);
			this.Controls.Add(this.lblC);
			this.Controls.Add(this.lblR);
			this.Controls.Add(this.lblL);
			this.Controls.Add(this.lblSCR2);
			this.Controls.Add(this.lblFIT);
			this.Controls.Add(this.lblTV_2);
			this.Controls.Add(this.lblSCR1);
			this.Controls.Add(this.lblHDTV);
			this.Controls.Add(this.lblSRC);
			this.Controls.Add(this.btnClearIcons);
			this.Controls.Add(this.lblTV);
			this.Controls.Add(this.lblWAV);
			this.Controls.Add(this.lblWMA_2);
			this.Controls.Add(this.lblOGG);
			this.Controls.Add(this.lblMP3);
			this.Controls.Add(this.lblWMA);
			this.Controls.Add(this.lblDTS);
			this.Controls.Add(this.lblAC3);
			this.Controls.Add(this.lblMPG_2);
			this.Controls.Add(this.lblWMV);
			this.Controls.Add(this.lblXVid);
			this.Controls.Add(this.lblDivX);
			this.Controls.Add(this.lblMPG);
			this.Controls.Add(this.btnExit);
			this.Controls.Add(this.lblNews);
			this.Controls.Add(this.lblWeb);
			this.Controls.Add(this.lblCD_DVD);
			this.Controls.Add(this.lblPhoto);
			this.Controls.Add(this.lblMovie);
			this.Controls.Add(this.lblMusic);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnScrollLines);
			this.Controls.Add(this.txtSecondLine);
			this.Controls.Add(this.txtFirstLine);
			this.Name = "MainForm";
			this.Text = "LCD_Demo";
			this.Load += new System.EventHandler(this.MainFormLoad);
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.RadioButton radioButton1;
		private System.Windows.Forms.RadioButton radioButton2;
		private System.Windows.Forms.RadioButton radioButton3;
		private System.Windows.Forms.RadioButton radioButton4;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button btnDiskOff;
		private System.Windows.Forms.Button btnDiskOn;
		private System.Windows.Forms.Label lblSCR2;
		private System.Windows.Forms.Label lblFIT;
		private System.Windows.Forms.Label lblTV_2;
		private System.Windows.Forms.Label lblSCR1;
		private System.Windows.Forms.Label lblHDTV;
		private System.Windows.Forms.Label lblSRC;
		private System.Windows.Forms.Button btnClearIcons;
		private System.Windows.Forms.Label lblMPG;
		private System.Windows.Forms.Label lblDivX;
		private System.Windows.Forms.Label lblXVid;
		private System.Windows.Forms.Label lblWMV;
		private System.Windows.Forms.Label lblMPG_2;
		private System.Windows.Forms.Label lblAC3;
		private System.Windows.Forms.Label lblDTS;
		private System.Windows.Forms.Label lblWMA;
		private System.Windows.Forms.Label lblMP3;
		private System.Windows.Forms.Label lblOGG;
		private System.Windows.Forms.Label lblWMA_2;
		private System.Windows.Forms.Label lblWAV;
		private System.Windows.Forms.Button btnExit;
		private System.Windows.Forms.Label lblNews;
		private System.Windows.Forms.Label lblWeb;
		private System.Windows.Forms.Label lblTV;
		private System.Windows.Forms.Label lblCD_DVD;
		private System.Windows.Forms.Label lblPhoto;
		private System.Windows.Forms.Label lblMovie;
		private System.Windows.Forms.Label lblMusic;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnScrollLines;
		private System.Windows.Forms.Button btnSend;
		private System.Windows.Forms.TextBox txtSecondLine;
		private System.Windows.Forms.TextBox txtFirstLine;
		
		void MainFormLoad(object sender, System.EventArgs e)
		{
			
		}

        private System.Windows.Forms.Label lblL;
        private System.Windows.Forms.Label lblR;
        private System.Windows.Forms.Label lblC;
        private System.Windows.Forms.Label lblSL;
        private System.Windows.Forms.Label lblLFE;
        private System.Windows.Forms.Label lblSR;
        private System.Windows.Forms.Label lblSPDIF;
        private System.Windows.Forms.Label lblRL;
        private System.Windows.Forms.Label lblRR;
        private System.Windows.Forms.Label lblREP;
        private System.Windows.Forms.Label lblSFL;
        private System.Windows.Forms.Label lblAlarm;
        private System.Windows.Forms.Label lblREC;
        private System.Windows.Forms.Label lblVol;
        private System.Windows.Forms.Label lblTime;
	}
}
