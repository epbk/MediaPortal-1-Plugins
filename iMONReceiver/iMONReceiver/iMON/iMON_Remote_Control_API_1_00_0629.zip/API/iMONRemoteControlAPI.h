#ifndef __IMON_REMOTE_CONTROL_API_H__
#define __IMON_REMOTE_CONTROL_API_H__

////////////////////////////////////
//	includes
/** iMONRemoteControlDefines.h
This header file defines several enumerations. Open this file and check the definition and usage of enumerations and structures*/
#include "iMONRemoteControlDefines.h"

#ifdef IMON_REMOTE_CONTROL_API_EXPORT
#define IMONRCAPI __declspec(dllexport)
#else
#define IMONRCAPI __declspec(dllimport)
#endif

#ifdef __cplusplus
extern "C" 
{
#endif	//__cplusplus

	/////////////////////////////////////
	/////	Interfaces
	/**RcResult IMON_RcApi_Init(HWND hwndNoti, UINT uMsgNotification)
	@brief	This function should be called to use other functions in iMON Remote Control API.\n 
	When the caller application calls this function, API tries to request Remote Control Plug-in Mode to iMON.
	@param	[in] hwndNoti	API will send/post message to this handle.
	@param	[in] uMsgNotification	API will send/post message to hwndNoti with this message identifier.
	@return	This function will return one of RcResult enumeration value.\n
	RCR_SUCCEEDED will be returned if succeeded. RCR_E_INVALIDARG or RCR_E_OUTOFMEMORY can be returned when error occurs.*/
	IMONRCAPI RcResult IMON_RcApi_Init(HWND hwndNoti, UINT uMsgNotification);

	/**RcResult IMON_RcApi_Uninit()
	@brief	This function should be called when the caller application need not use this API any more.\n 
	If this function call is missed, iMON or other application can't process IR signals properly.\n
	@return	This function will return one of RcResult enumeration value.\n
	RCR_SUCCEEDED will be returned if succeeded.*/
	IMONRCAPI RcResult IMON_RcApi_Uninit();

	/**RcResult IMON_RcApi_IsInited()
	@brief	This function can be used when the caller application wants to know if API is initialized.\n 
	@return	This function will return one of RcResult enumeration value.\n
	If API is initialized, this call will return RCR_S_INITED. Otherwise RCR_S_NOT_INITED will be returned.*/
	IMONRCAPI RcResult IMON_RcApi_IsInited();

	/**RcResult IMON_RcApi_IsPluginModeEnabled()
	@brief	This function can be used when the caller application wants to know if API can control iMON Remote Control.\n
	@return	This function will return one of RcResult enumeration value.\n
	If API can control iMON Remote Control, this call will return RCR_S_IN_PLUGIN_MODE. Otherwise RCR_S_NOT_IN_PLUGIN_MODE will be returned.*/
	IMONRCAPI RcResult IMON_RcApi_IsPluginModeEnabled();

#ifdef __cplusplus
}
#endif	//__cplusplus

#endif	//__IMON_REMOTE_CONTROL_API_H__