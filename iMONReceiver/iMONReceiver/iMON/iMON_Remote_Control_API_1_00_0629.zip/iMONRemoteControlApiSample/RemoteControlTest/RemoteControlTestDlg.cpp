// RemoteControlTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "RemoteControlTest.h"
#include "RemoteControlTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CRemoteControlTestDlg dialog




CRemoteControlTestDlg::CRemoteControlTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRemoteControlTestDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CRemoteControlTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_LIST1, m_List);
}

BEGIN_MESSAGE_MAP(CRemoteControlTestDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP

	ON_MESSAGE(WM_RC_PLUGIN_NOTIFY, OnRcPluginNotify)
	ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedButtonInit)
	ON_BN_CLICKED(IDC_BUTTON2, OnBnClickedButtonReset)
END_MESSAGE_MAP()


// CRemoteControlTestDlg message handlers

BOOL CRemoteControlTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	////ShowWindow(SW_MINIMIZE);

	UpdateControlUI();
	UpdateData(FALSE);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CRemoteControlTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CRemoteControlTestDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CRemoteControlTestDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CRemoteControlTestDlg::OnDestroy() 
{
	CDialog::OnDestroy();

	IMON_RcApi_Uninit();
}

LRESULT CRemoteControlTestDlg::OnRcPluginNotify(WPARAM wParam, LPARAM lParam)
{
	if(!GetSafeHwnd() || !IsWindow(GetSafeHwnd()))		return 0;

	switch(wParam)
	{
	case RCNM_PLUGIN_SUCCEED:
	case RCNM_IMON_RESTARTED:
	case RCNM_HW_CONNECTED:
		{
			GetDlgItem(IDC_BUTTON1)->EnableWindow(TRUE);
			UpdateControlUI();

			OnRcPluginMessage(wParam, FALSE);
		}
		break;

	case RCNM_PLUGIN_FAILED:
	case RCNM_HW_DISCONNECTED:
	case RCNM_IMON_CLOSED:
		{
			GetDlgItem(IDC_BUTTON1)->EnableWindow(TRUE);
			UpdateControlUI();

			OnRcPluginMessage(lParam, TRUE);
		}
		break;

	case RCNM_RC_REMOTE:
		{
			CString strData = _T("");
			strData.Format(_T("Current Remote: %s"), GetRemoteName(lParam));
			m_List.InsertString(0, strData);
		}
		break;

	case RCNM_RC_BUTTON_DOWN:
		{
			CString strData = _T("");
			strData.Format(_T("Button Down: %s"), GetButtonName(lParam));
			m_List.InsertString(0, strData);
		}
		break;

	case RCNM_RC_BUTTON_UP:
		{
			CString strData = _T("");
			strData.Format(_T("Button Up: %s"), GetButtonName(lParam));
			m_List.InsertString(0, strData);
		}
		break;

	case RCNM_KNOB_ACTION:
		{
			CString strData = _T("");
			strData.Format(_T("Knob Action: %s"), GetButtonName(lParam));
			m_List.InsertString(0, strData);
		}
		break;
	}
	return 0;
}

void CRemoteControlTestDlg::Init()
{
	Uninit();

	IMON_RcApi_Init(this->GetSafeHwnd(), WM_RC_PLUGIN_NOTIFY);
	GetDlgItem(IDC_BUTTON1)->EnableWindow(FALSE);
}

void CRemoteControlTestDlg::Uninit()
{
	IMON_RcApi_Uninit();

	UpdateControlUI();
}

void CRemoteControlTestDlg::OnRcPluginMessage(UINT uErrCode, BOOL bError)
{
	CString strErrMsg = _T("");

	if(bError)
	{
		switch(uErrCode)
		{
		case RCN_ERR_IN_USED:			strErrMsg = _T("Plug-in is Already Used by Other Application.");				break;
		case RCN_ERR_HW_DISCONNECTED:	strErrMsg = _T("iMON HW is Not Connected.");									break;
		case RCN_ERR_NOT_SUPPORTED_HW:	strErrMsg = _T("The Connected iMON HW doesn't Support Plug-in.");				break;
		case RCN_ERR_PLUGIN_DISABLED:	strErrMsg = _T("Plug-in Mode Option is Disabled.");								break;
		case RCN_ERR_IMON_NO_REPLY:		strErrMsg = _T("The Latest iMON is Not Installed or iMON Not Running.");		break;
		case RCN_ERR_UNKNOWN:			strErrMsg = _T("Unknown Failure.");												break;
		}
	}
	else
	{
		switch(uErrCode)
		{
		case RCNM_PLUGIN_SUCCEED:		strErrMsg = _T("Plug-in Mode Inited Successfully.");			break;
		case RCNM_IMON_RESTARTED:		strErrMsg = _T("iMON Started and Plug-in Mode Inited.");		break;
		case RCNM_HW_CONNECTED:			strErrMsg = _T("iMON HW Connected and Plug-in Mode Inited.");	break;
		}
	}

	GetDlgItem(IDC_STATIC_INFO)->SetWindowText((LPCTSTR)strErrMsg);
}

void CRemoteControlTestDlg::UpdateControlUI()
{
	GetDlgItem(IDC_STATIC_INFO)->SetWindowText(_T(""));

	if(IMON_RcApi_IsInited() != RCR_S_INITED)		GetDlgItem(IDC_BUTTON1)->SetWindowText(_T("Init Plug-in"));
	else											GetDlgItem(IDC_BUTTON1)->SetWindowText(_T("Uninit Plug-in"));
}

void CRemoteControlTestDlg::OnBnClickedButtonInit()
{
	if(IMON_RcApi_IsInited() != RCR_S_INITED)		Init();
	else											Uninit();
}

void CRemoteControlTestDlg::OnBnClickedButtonReset()
{
	m_List.ResetContent();
}

CString CRemoteControlTestDlg::GetRemoteName(int nRemote)
{
	CString strRemote = _T("");

	switch(nRemote)
	{
	case REMOTE_NONE:		strRemote = _T("No Selected Remote");	break;
	case REMOTE_IMON_RC	:	strRemote = _T("iMON RC Remote");		break;
	case REMOTE_IMON_RSC:	strRemote = _T("iMON RSC Remote");		break;
	case REMOTE_IMON_MM:	strRemote = _T("iMON MM Remote");		break;
	case REMOTE_IMON_EX:	strRemote = _T("iMON EX Remote");		break;
	case REMOTE_IMON_PAD:	strRemote = _T("iMON PAD Remote");		break;
	case REMOTE_IMON_24G:	strRemote = _T("iMON 2.4G Remote");		break;
	case REMOTE_IMON_MINI:	strRemote = _T("IMON MINI Remote");		break;
	case REMOTE_MCE:		strRemote = _T("MCE Remote");			break;
	default:				strRemote.Format(_T("Remote %.3d"), nRemote);	break;
	}
	return strRemote;
}

CString CRemoteControlTestDlg::GetButtonName(int nButton)
{
	CString strButton = _T("");

	switch(nButton)
	{
	case RC_BTN_PLAY:				strButton = _T("Play");	break;
	case RC_BTN_PAUSE:				strButton = _T("Pause");	break;
	case RC_BTN_STOP:				strButton = _T("Stop");	break;
	case RC_BTN_PREV:				strButton = _T("Prev");	break;
	case RC_BTN_NEXT:				strButton = _T("Next");	break;
	case RC_BTN_REW:				strButton = _T("Rewind");	break;
	case RC_BTN_FF:					strButton = _T("Forward");	break;
	case RC_BTN_EJECT:				strButton = _T("Eject");	break;
	case RC_BTN_VOL_UP:				strButton = _T("Volume Up");	break;
	case RC_BTN_VOL_DOWN:			strButton = _T("Volume Down");	break;
	case RC_BTN_MUTE:				strButton = _T("Mute");	break;
	case RC_BTN_FILE_OPEN:			strButton = _T("Open");	break;
	case RC_BTN_RECORD:				strButton = _T("Record");	break;
	case RC_BTN_QUICK_LAUNCH:		strButton = _T("Quick Launch");	break;
	case RC_BTN_CH_UP:				strButton = _T("Channel Up");	break;
	case RC_BTN_CH_DOWN:			strButton = _T("Channel Down");	break;
	case RC_BTN_A_UP:				strButton = _T("Up");	break;
	case RC_BTN_A_DOWN:				strButton = _T("Down");	break;
	case RC_BTN_A_LEFT:				strButton = _T("Left");	break;
	case RC_BTN_A_RIGHT:			strButton = _T("Right");	break;
	case RC_BTN_ENTER:				strButton = _T("Enter");	break;
	case RC_BTN_BACKSPACE:			strButton = _T("Backspace");	break;
	case RC_BTN_ESC:				strButton = _T("Esc");	break;
	case RC_BTN_SPACE:				strButton = _T("Space");	break;
	case RC_BTN_LAUNCHER:			strButton = _T("App. Launcher");	break;
	case RC_BTN_SWITCHER:			strButton = _T("Task Switcher");	break;
	case RC_BTN_TIMER:				strButton = _T("Timer");	break;
	case RC_BTN_SHIFT_TAB:			strButton = _T("Shift Tab");	break;
	case RC_BTN_TAB:				strButton = _T("Tab");	break;
	case RC_BTN_MYMUSIC:			strButton = _T("Music");	break;
	case RC_BTN_MYMOVIE:			strButton = _T("Videos");	break;
	case RC_BTN_MYPHOTO:			strButton = _T("Pictures");	break;
	case RC_BTN_MYTV:				strButton = _T("TV");	break;
	case RC_BTN_THUMBNAIL:			strButton = _T("Thumbnail");	break;
	case RC_BTN_ASPECT:				strButton = _T("Zoom (Aspect Ratio)");	break;
	case RC_BTN_FULLSCR:			strButton = _T("Full Screen");	break;
	case RC_BTN_MYDVD:				strButton = _T("DVD");	break;
	case RC_BTN_DVD_MENU:			strButton = _T("DVD Menu");	break;
	case RC_BTN_CAPTION:			strButton = _T("Subtitle (DVD Caption)");	break;
	case RC_BTN_LANG:				strButton = _T("Audio (DVD Language)");	break;
	case RC_BTN_APP_EXIT:			strButton = _T("App Exit");	break;
	case RC_BTN_WINDOWS:			strButton = _T("Windows");	break;
	case RC_BTN_MENU:				strButton = _T("Menu");	break;
	case RC_BTN_MOUSEKBD:			strButton = _T("Mouse / Keyboard");	break;
	case RC_BTN_NUM1:				strButton = _T("Number 1");	break;
	case RC_BTN_NUM2:				strButton = _T("Number 2");	break;
	case RC_BTN_NUM3:				strButton = _T("Number 3");	break;
	case RC_BTN_NUM4:				strButton = _T("Number 4");	break;
	case RC_BTN_NUM5:				strButton = _T("Number 5");	break;
	case RC_BTN_NUM6:				strButton = _T("Number 6");	break;
	case RC_BTN_NUM7:				strButton = _T("Number 7");	break;
	case RC_BTN_NUM8:				strButton = _T("Number 8");	break;
	case RC_BTN_NUM9:				strButton = _T("Number 9");	break;
	case RC_BTN_NUM0:				strButton = _T("Number 0");	break;
	case RC_BTN_POWER:				strButton = _T("Power");	break;
	case RC_BTN_BOOKMARK:			strButton = _T("Bookmark");	break;
	case RC_BTN_PLAY_PAUSE:			strButton = _T("Play/Pause");	break;
	case RC_BTN_STAR:				strButton = _T("Star (*)");	break;
	case RC_BTN_SHARP:				strButton = _T("Sharp (#)");	break;
	case RC_BTN_RADIO:				strButton = _T("Radio");	break;
	case RC_BTN_LIVE_TV:			strButton = _T("Live TV");	break;
	case RC_BTN_RECORDED_TV:		strButton = _T("Recorded TV");	break;
	case RC_BTN_GUIDE:				strButton = _T("TV Guide");	break;
	case RC_BTN_NUM_CLEAR:			strButton = _T("Clear");	break;
	case RC_BTN_NUM_PRINT:			strButton = _T("Print");	break;
	case RC_BTN_NUM_ENTER:			strButton = _T("Enter (Numpad)");	break;
	case RC_BTN_MESSENGER:			strButton = _T("Messenger");	break;
	case RC_BTN_VIDEOTEXT:			strButton = _T("Videotext");	break;
	case RC_BTN_VT_RED:				strButton = _T("Red");	break;
	case RC_BTN_VT_GREEN:			strButton = _T("Green");	break;
	case RC_BTN_VT_YELLOW:			strButton = _T("Yellow");	break;
	case RC_BTN_VT_BLUE:			strButton = _T("Blue");	break;
	case RC_BTN_USER_01:			strButton = _T("User01");	break;
	case RC_BTN_USER_02:			strButton = _T("User02");	break;
	case RC_BTN_USER_03:			strButton = _T("User03");	break;
	case RC_BTN_USER_04:			strButton = _T("User04");	break;
	case RC_BTN_USER_05:			strButton = _T("User05");	break;
	case RC_BTN_USER_06:			strButton = _T("User06");	break;
	case RC_BTN_USER_07:			strButton = _T("User07");	break;
	case RC_BTN_USER_08:			strButton = _T("User08");	break;
	case RC_BTN_USER_09:			strButton = _T("User09");	break;
	case RC_BTN_USER_10:			strButton = _T("User10");	break;
	case RC_BTN_VISUALIZATION:		strButton = _T("Visualization");	break;
	case RC_BTN_SLIDESHOW:			strButton = _T("Slideshow");	break;
	case RC_BTN_ANGLE:				strButton = _T("Angle");	break;

	case RC_VKNOB_PUSH:				strButton = _T("Volume Knob Push");	break;
	case RC_VKNOB_LONG:				strButton = _T("Volume Knob Long Push");	break;
	case RC_VKNOB_ROTATE_L:			strButton = _T("Volume Knob Rotate Left");	break;
	case RC_VKNOB_ROTATE_R:			strButton = _T("Volume Knob Rotate Right");	break;
	case RC_NKNOB_PUSH:				strButton = _T("Navigation Knob Push");	break;
	case RC_NKNOB_LONG:				strButton = _T("Navigation Knob Long Push");	break;
	case RC_NKNOB_ROTATE_L:			strButton = _T("Navigation Knob Rotate Left");	break;
	case RC_NKNOB_ROTATE_R:			strButton = _T("Navigation Knob Rotate Right");	break;

	default:						strButton.Format(_T("Button %.3d"), nButton);;	break;
	}
	return strButton;
}