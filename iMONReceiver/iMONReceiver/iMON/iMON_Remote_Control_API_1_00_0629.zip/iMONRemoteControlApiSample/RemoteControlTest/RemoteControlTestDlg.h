// RemoteControlTestDlg.h : header file
//

#pragma once

#define WM_RC_PLUGIN_NOTIFY	WM_APP + 1002


// CRemoteControlTestDlg dialog
class CRemoteControlTestDlg : public CDialog
{
// Construction
public:
	CRemoteControlTestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_REMOTECONTROLTEST_DIALOG };
	CListBox m_List;

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	void Init();
	void Uninit();
	void OnRcPluginMessage(UINT uErrCode, BOOL bError);
	void UpdateControlUI();

	CString GetRemoteName(int nRemote);
	CString GetButtonName(int nButton);

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDestroy();
	DECLARE_MESSAGE_MAP()

	afx_msg LRESULT OnRcPluginNotify(WPARAM, LPARAM);
	afx_msg void OnBnClickedButtonInit();
	afx_msg void OnBnClickedButtonReset();
};
